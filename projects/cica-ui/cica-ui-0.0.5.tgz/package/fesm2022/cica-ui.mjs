import * as i0 from "@angular/core";
import { Component, Directive, TemplateRef, contentChild, contentChildren, inject, input, model, output, viewChildren } from "@angular/core";
import { AsyncPipe, NgTemplateOutlet } from "@angular/common";
import { toObservable } from "@angular/core/rxjs-interop";
import { Router, RouterLink, RouterLinkActive } from "@angular/router";
import { Subject, combineLatest, map, merge, scan, startWith, switchMap } from "rxjs";
var SidebarLinkTemplateDirective = class SidebarLinkTemplateDirective {
	templateRef = inject(TemplateRef);
	url = input.required(...ngDevMode ? [{ debugName: "url" }] : 	/* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : 	/* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: SidebarLinkTemplateDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.1.6",
		type: SidebarLinkTemplateDirective,
		isStandalone: true,
		selector: "[cicaSidebarLink]",
		inputs: {
			url: {
				classPropertyName: "url",
				publicName: "url",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.1.6",
	ngImport: i0,
	type: SidebarLinkTemplateDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[cicaSidebarLink]" }]
	}],
	propDecorators: {
		url: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "url",
				required: true
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}]
	}
});
var SidebarLinkComponent = class SidebarLinkComponent {
	url = input(...ngDevMode ? [void 0, { debugName: "url" }] : 	/* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : 	/* istanbul ignore next */ []);
	linkClick = output();
	links$ = viewChildren(RouterLinkActive, ...ngDevMode ? [{ debugName: "links$" }] : 	/* istanbul ignore next */ []);
	labelTemplate = contentChild("labelTemplate", ...ngDevMode ? [{ debugName: "labelTemplate" }] : 	/* istanbul ignore next */ []);
	linkTemplates = contentChildren(SidebarLinkTemplateDirective, ...ngDevMode ? [{ debugName: "linkTemplates" }] : 	/* istanbul ignore next */ []);
	router = inject(Router);
	toggle = new Subject();
	isOpen$ = merge(toObservable(this.links$).pipe(switchMap((links) => combineLatest(links.map((e) => e.isActiveChange.asObservable().pipe(startWith(false)))).pipe(map((isActiveAnyLink) => ({
		event: "navigate",
		value: isActiveAnyLink.some(Boolean)
	}))))), this.toggle.asObservable()).pipe(scan((acc, cur) => {
		if (cur.event === "click") return !acc;
		return cur?.value ?? false;
	}, false));
	linkClicked() {
		if (this.url()) this.router.navigate([this.url()]);
		this.linkClick.emit();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: SidebarLinkComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.1.6",
		type: SidebarLinkComponent,
		isStandalone: true,
		selector: "cica-sidebar-link",
		inputs: {
			url: {
				classPropertyName: "url",
				publicName: "url",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { linkClick: "linkClick" },
		queries: [{
			propertyName: "labelTemplate",
			first: true,
			predicate: ["labelTemplate"],
			descendants: true,
			isSignal: true
		}, {
			propertyName: "linkTemplates",
			predicate: SidebarLinkTemplateDirective,
			isSignal: true
		}],
		viewQueries: [{
			propertyName: "links$",
			predicate: RouterLinkActive,
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "@let hasChildren = linkTemplates().length > 0;\n<div\n  class=\"nav-item\"\n  (click)=\"linkClicked()\"\n  [class.dropdown-container]=\"hasChildren\"\n>\n  <a\n    (click)=\"toggle.next({ event: 'click' })\"\n    class=\"nav-link\"\n    [class.dropdown-toggle]=\"hasChildren\"\n  >\n    <ng-content select=\".link-icon\" />\n    <span class=\"nav-label\"  [class.no-content]=\"!labelTemplate() && !label()\">\n      @if (labelTemplate(); as template) {\n    <ng-container\n      [ngTemplateOutlet]=\"template\"\n    />\n  } @else {\n    {{label()}}\n  }\n    </span>\n    @if (hasChildren) {\n      <span class=\"dropdown-icon\">\n\n<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24\" viewBox=\"0 0 24 24\" width=\"24\" fill=\"currentColor\">\n  <path d=\"M7.41 8.59 12 13.17l4.59-4.58L18 10l-6 6-6-6z\"/>\n</svg>\n\n      </span>\n    }\n  </a>\n  <div\n    class=\"dropdown-menu\"\n    [class.open]=\"isOpen$ | async\"\n  >\n    @for (childLink of linkTemplates(); track childLink.url()) {\n      <div class=\"nav-item\">\n        <a\n          [routerLink]=\"childLink.url()\"\n          routerLinkActive=\"active\"\n          class=\"nav-link dropdown-link\"\n          >\n          <ng-template [ngTemplateOutlet]=\"childLink.templateRef\">\n\n          </ng-template></a\n        >\n      </div>\n    } @empty {\n      <div class=\"nav-item\">\n        <a\n          [routerLink]=\"url()\"\n          routerLinkActive=\"active\"\n          class=\"nav-link dropdown-link\"\n          [class.no-content]=\"!labelTemplate() && !label()\"\n          >      @if (labelTemplate(); as template) {\n    <ng-container\n      [ngTemplateOutlet]=\"template\"\n    />\n  } @else {\n    {{label()}}\n  }</a\n        >\n      </div>\n    }\n  </div>\n</div>\n",
		styles: [":host .nav-item{margin:0 .5rem}:host .no-content{display:none}:host .nav-item .nav-link{color:var(--sidebar-light, #eef2ff);display:flex;gap:.75rem;white-space:nowrap;border-radius:.5rem;padding:.75rem;align-items:center;text-decoration:none;border:1px solid var(--sidebar-dark, #151a2d);transition:.4s ease;cursor:pointer}:host .nav-item:is(:hover,.open)>.nav-link:not(.dropdown-title){color:var(--sidebar-dark, #151a2d);background-color:var(--sidebar-light, #eef2ff)}:host .nav-item:has(.dropdown-menu):has(a.active) .nav-link:not(.dropdown-link),:host a.active{font-weight:700}:host .nav-link .nav-label{transition:opacity 3s ease;width:100%}:host .dropdown-icon{transition:transform .3s ease;transform:rotate(90deg)}:host .dropdown-toggle{cursor:pointer}:host-context(.sidebar-size.sm.sidebar-position-left) .dropdown-menu .nav-link,:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:not(:hover)) .dropdown-menu .nav-link,:host-context(.sidebar.sidebar-position-top) .dropdown-menu .nav-link{min-width:160px}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-item .dropdown-menu{display:none;position:absolute;width:200px;height:auto!important;overflow:visible;opacity:1;z-index:1001;pointer-events:auto;background-color:var(--sidebar-dark, #151a2d);border-top-right-radius:.5rem;border-bottom-right-radius:.5rem}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) :host:hover>.dropdown-menu{display:block}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) :host:hover>.dropdown-menu:has(.no-content),:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-link.dropdown-link.no-content{display:none}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-item{margin:0 .5rem}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-item>.dropdown-menu{left:100%;top:0}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-link :where(.nav-label,.dropdown-icon),:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:not(:hover)) .nav-link :where(.nav-label,.dropdown-icon){display:none}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-item .nav-link,:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:not(:hover)) .nav-item .nav-link{justify-content:center}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .dropdown-menu .nav-item .nav-link,:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:not(:hover)) .dropdown-menu .nav-item .nav-link{justify-content:start}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-item:has(.dropdown-menu):has(a.active) .nav-link:not(.dropdown-link),:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:not(:hover)) .nav-item:has(.dropdown-menu):has(a.active) .nav-link:not(.dropdown-link){color:var(--sidebar-primary, rgb(86, 107, 223))}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .dropdown-menu .nav-item .dropdown-title,:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:not(:hover)) .dropdown-menu .nav-item .dropdown-title{display:block}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-link .dropdown-icon,:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:not(:hover)) .nav-link .dropdown-icon{transition:opacity .3s 0s easy}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .dropdown-menu:has(.dropdown-link),:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:not(:hover)) .dropdown-menu:has(.dropdown-link){padding:.5rem}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-item:hover>.dropdown-menu,:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:not(:hover)) .nav-item:hover>.dropdown-menu{display:block;opacity:1;pointer-events:auto;transition:all .4s ease}.nav-item{position:relative}.dropdown-container .dropdown-icon{margin:0 -4px 0 auto;transition:transform .4s ease,opacity .3s .2s easey}.dropdown-menu{height:0;overflow-y:hidden;padding-left:1rem;transition:height .4s ease}.dropdown-menu .nav-item .nav-link,.dropdown-menu .nav-item .nav-link .dropdown-title{color:var(--sidebar-light, #eef2ff);padding:.5rem .75rem}.dropdown-menu .nav-item .nav-link .dropdown-title{display:none}.dropdown-menu:has(.dropdown-link) .nav-item .dropdown-title{font-weight:500;padding:.5rem .75rem}:host-context(.sidebar.sidebar-position-top) .dropdown-menu{border-radius:.5rem;padding-bottom:.25rem;padding:.5rem 0}:host-context(.sidebar.sidebar-position-top) .nav-item.dropdown-container{padding:.25rem 0}:host-context(.sidebar.sidebar-position-top) .nav-item:has(.dropdown-menu):has(a.active):not(:hover) .nav-link:not(.dropdown-link){border-bottom:.125rem solid var(--sidebar-primary, rgb(86, 107, 223));border-bottom-left-radius:0;border-bottom-right-radius:0}:host-context(.sidebar.sidebar-position-top) .nav-item:has(.dropdown-menu):has(a.active):hover .nav-link:not(.dropdown-link){color:var(--sidebar-primary, rgb(86, 107, 223))}:host-context(.sidebar.sidebar-position-top) .nav-item.dropdown-container:hover>.dropdown-menu{display:block;height:auto;overflow:visible;opacity:1;pointer-events:auto}:host-context(.sidebar.sidebar-position-top) .dropdown-menu{position:absolute;top:100%;left:0;transform:translateY(.25rem);z-index:1001;min-width:100%;padding-left:0;background-color:var(--sidebar-dark, #151a2d);display:none}:host-context(.sidebar.sidebar-position-top) .dropdown-icon{display:none}:host-context(.sidebar.sidebar-position-left) .dropdown-container .dropdown-menu.open{height:auto;overflow:visible}:host-context(.sidebar.sidebar-position-left) .dropdown-container.open .dropdown-icon{transform:rotate(180deg)}:host-context(.sidebar.sidebar-position-left) .nav-item:has(.dropdown-menu.open) .dropdown-icon{transform:rotate(0)}:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:hover) a.active,:host-context(.sidebar.sidebar-size-lg.sidebar-position-left) a.active{border-left:.25rem solid var(--sidebar-primary, rgb(86, 107, 223))}:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:hover) .nav-item:has(.dropdown-menu a.active),:host-context(.sidebar.sidebar-size-lg.sidebar-position-left) .nav-item:has(.dropdown-menu a.active){border-left:.25rem solid var(--sidebar-primary, rgb(86, 107, 223));margin-left:.25rem}:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:hover) .nav-item .dropdown-menu a.nav-link.dropdown-link.active,:host-context(.sidebar.sidebar-size-lg.sidebar-position-left) .nav-item .dropdown-menu a.nav-link.dropdown-link.active{border-left:none}:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:hover) .nav-link :where(.nav-label,.dropdown-icon),:host-context(.sidebar.sidebar-size-lg.sidebar-position-left) .nav-link :where(.nav-label,.dropdown-icon){display:inline}:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:hover) .dropdown-menu,:host-context(.sidebar.sidebar-size-lg.sidebar-position-left) .dropdown-menu{position:static;opacity:1;pointer-events:auto;border-radius:0;background:transparent}:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:hover) .dropdown-container .dropdown-menu.open,:host-context(.sidebar.sidebar-size-lg.sidebar-position-left) .dropdown-container .dropdown-menu.open{display:block;height:auto;overflow:visible}\n"],
		dependencies: [
			{
				kind: "directive",
				type: RouterLink,
				selector: "[routerLink]",
				inputs: [
					"target",
					"queryParams",
					"fragment",
					"queryParamsHandling",
					"state",
					"info",
					"relativeTo",
					"preserveFragment",
					"skipLocationChange",
					"replaceUrl",
					"browserUrl",
					"routerLink"
				]
			},
			{
				kind: "directive",
				type: RouterLinkActive,
				selector: "[routerLinkActive]",
				inputs: [
					"routerLinkActiveOptions",
					"ariaCurrentWhenActive",
					"routerLinkActive"
				],
				outputs: ["isActiveChange"],
				exportAs: ["routerLinkActive"]
			},
			{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			},
			{
				kind: "pipe",
				type: AsyncPipe,
				name: "async"
			}
		]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.1.6",
	ngImport: i0,
	type: SidebarLinkComponent,
	decorators: [{
		type: Component,
		args: [{
			imports: [
				RouterLink,
				RouterLinkActive,
				AsyncPipe,
				NgTemplateOutlet
			],
			selector: "cica-sidebar-link",
			template: "@let hasChildren = linkTemplates().length > 0;\n<div\n  class=\"nav-item\"\n  (click)=\"linkClicked()\"\n  [class.dropdown-container]=\"hasChildren\"\n>\n  <a\n    (click)=\"toggle.next({ event: 'click' })\"\n    class=\"nav-link\"\n    [class.dropdown-toggle]=\"hasChildren\"\n  >\n    <ng-content select=\".link-icon\" />\n    <span class=\"nav-label\"  [class.no-content]=\"!labelTemplate() && !label()\">\n      @if (labelTemplate(); as template) {\n    <ng-container\n      [ngTemplateOutlet]=\"template\"\n    />\n  } @else {\n    {{label()}}\n  }\n    </span>\n    @if (hasChildren) {\n      <span class=\"dropdown-icon\">\n\n<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24\" viewBox=\"0 0 24 24\" width=\"24\" fill=\"currentColor\">\n  <path d=\"M7.41 8.59 12 13.17l4.59-4.58L18 10l-6 6-6-6z\"/>\n</svg>\n\n      </span>\n    }\n  </a>\n  <div\n    class=\"dropdown-menu\"\n    [class.open]=\"isOpen$ | async\"\n  >\n    @for (childLink of linkTemplates(); track childLink.url()) {\n      <div class=\"nav-item\">\n        <a\n          [routerLink]=\"childLink.url()\"\n          routerLinkActive=\"active\"\n          class=\"nav-link dropdown-link\"\n          >\n          <ng-template [ngTemplateOutlet]=\"childLink.templateRef\">\n\n          </ng-template></a\n        >\n      </div>\n    } @empty {\n      <div class=\"nav-item\">\n        <a\n          [routerLink]=\"url()\"\n          routerLinkActive=\"active\"\n          class=\"nav-link dropdown-link\"\n          [class.no-content]=\"!labelTemplate() && !label()\"\n          >      @if (labelTemplate(); as template) {\n    <ng-container\n      [ngTemplateOutlet]=\"template\"\n    />\n  } @else {\n    {{label()}}\n  }</a\n        >\n      </div>\n    }\n  </div>\n</div>\n",
			styles: [":host .nav-item{margin:0 .5rem}:host .no-content{display:none}:host .nav-item .nav-link{color:var(--sidebar-light, #eef2ff);display:flex;gap:.75rem;white-space:nowrap;border-radius:.5rem;padding:.75rem;align-items:center;text-decoration:none;border:1px solid var(--sidebar-dark, #151a2d);transition:.4s ease;cursor:pointer}:host .nav-item:is(:hover,.open)>.nav-link:not(.dropdown-title){color:var(--sidebar-dark, #151a2d);background-color:var(--sidebar-light, #eef2ff)}:host .nav-item:has(.dropdown-menu):has(a.active) .nav-link:not(.dropdown-link),:host a.active{font-weight:700}:host .nav-link .nav-label{transition:opacity 3s ease;width:100%}:host .dropdown-icon{transition:transform .3s ease;transform:rotate(90deg)}:host .dropdown-toggle{cursor:pointer}:host-context(.sidebar-size.sm.sidebar-position-left) .dropdown-menu .nav-link,:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:not(:hover)) .dropdown-menu .nav-link,:host-context(.sidebar.sidebar-position-top) .dropdown-menu .nav-link{min-width:160px}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-item .dropdown-menu{display:none;position:absolute;width:200px;height:auto!important;overflow:visible;opacity:1;z-index:1001;pointer-events:auto;background-color:var(--sidebar-dark, #151a2d);border-top-right-radius:.5rem;border-bottom-right-radius:.5rem}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) :host:hover>.dropdown-menu{display:block}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) :host:hover>.dropdown-menu:has(.no-content),:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-link.dropdown-link.no-content{display:none}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-item{margin:0 .5rem}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-item>.dropdown-menu{left:100%;top:0}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-link :where(.nav-label,.dropdown-icon),:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:not(:hover)) .nav-link :where(.nav-label,.dropdown-icon){display:none}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-item .nav-link,:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:not(:hover)) .nav-item .nav-link{justify-content:center}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .dropdown-menu .nav-item .nav-link,:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:not(:hover)) .dropdown-menu .nav-item .nav-link{justify-content:start}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-item:has(.dropdown-menu):has(a.active) .nav-link:not(.dropdown-link),:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:not(:hover)) .nav-item:has(.dropdown-menu):has(a.active) .nav-link:not(.dropdown-link){color:var(--sidebar-primary, rgb(86, 107, 223))}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .dropdown-menu .nav-item .dropdown-title,:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:not(:hover)) .dropdown-menu .nav-item .dropdown-title{display:block}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-link .dropdown-icon,:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:not(:hover)) .nav-link .dropdown-icon{transition:opacity .3s 0s easy}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .dropdown-menu:has(.dropdown-link),:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:not(:hover)) .dropdown-menu:has(.dropdown-link){padding:.5rem}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-item:hover>.dropdown-menu,:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:not(:hover)) .nav-item:hover>.dropdown-menu{display:block;opacity:1;pointer-events:auto;transition:all .4s ease}.nav-item{position:relative}.dropdown-container .dropdown-icon{margin:0 -4px 0 auto;transition:transform .4s ease,opacity .3s .2s easey}.dropdown-menu{height:0;overflow-y:hidden;padding-left:1rem;transition:height .4s ease}.dropdown-menu .nav-item .nav-link,.dropdown-menu .nav-item .nav-link .dropdown-title{color:var(--sidebar-light, #eef2ff);padding:.5rem .75rem}.dropdown-menu .nav-item .nav-link .dropdown-title{display:none}.dropdown-menu:has(.dropdown-link) .nav-item .dropdown-title{font-weight:500;padding:.5rem .75rem}:host-context(.sidebar.sidebar-position-top) .dropdown-menu{border-radius:.5rem;padding-bottom:.25rem;padding:.5rem 0}:host-context(.sidebar.sidebar-position-top) .nav-item.dropdown-container{padding:.25rem 0}:host-context(.sidebar.sidebar-position-top) .nav-item:has(.dropdown-menu):has(a.active):not(:hover) .nav-link:not(.dropdown-link){border-bottom:.125rem solid var(--sidebar-primary, rgb(86, 107, 223));border-bottom-left-radius:0;border-bottom-right-radius:0}:host-context(.sidebar.sidebar-position-top) .nav-item:has(.dropdown-menu):has(a.active):hover .nav-link:not(.dropdown-link){color:var(--sidebar-primary, rgb(86, 107, 223))}:host-context(.sidebar.sidebar-position-top) .nav-item.dropdown-container:hover>.dropdown-menu{display:block;height:auto;overflow:visible;opacity:1;pointer-events:auto}:host-context(.sidebar.sidebar-position-top) .dropdown-menu{position:absolute;top:100%;left:0;transform:translateY(.25rem);z-index:1001;min-width:100%;padding-left:0;background-color:var(--sidebar-dark, #151a2d);display:none}:host-context(.sidebar.sidebar-position-top) .dropdown-icon{display:none}:host-context(.sidebar.sidebar-position-left) .dropdown-container .dropdown-menu.open{height:auto;overflow:visible}:host-context(.sidebar.sidebar-position-left) .dropdown-container.open .dropdown-icon{transform:rotate(180deg)}:host-context(.sidebar.sidebar-position-left) .nav-item:has(.dropdown-menu.open) .dropdown-icon{transform:rotate(0)}:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:hover) a.active,:host-context(.sidebar.sidebar-size-lg.sidebar-position-left) a.active{border-left:.25rem solid var(--sidebar-primary, rgb(86, 107, 223))}:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:hover) .nav-item:has(.dropdown-menu a.active),:host-context(.sidebar.sidebar-size-lg.sidebar-position-left) .nav-item:has(.dropdown-menu a.active){border-left:.25rem solid var(--sidebar-primary, rgb(86, 107, 223));margin-left:.25rem}:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:hover) .nav-item .dropdown-menu a.nav-link.dropdown-link.active,:host-context(.sidebar.sidebar-size-lg.sidebar-position-left) .nav-item .dropdown-menu a.nav-link.dropdown-link.active{border-left:none}:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:hover) .nav-link :where(.nav-label,.dropdown-icon),:host-context(.sidebar.sidebar-size-lg.sidebar-position-left) .nav-link :where(.nav-label,.dropdown-icon){display:inline}:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:hover) .dropdown-menu,:host-context(.sidebar.sidebar-size-lg.sidebar-position-left) .dropdown-menu{position:static;opacity:1;pointer-events:auto;border-radius:0;background:transparent}:host-context(.sidebar.sidebar-size-md.sidebar-position-left app-sidebar:hover) .dropdown-container .dropdown-menu.open,:host-context(.sidebar.sidebar-size-lg.sidebar-position-left) .dropdown-container .dropdown-menu.open{display:block;height:auto;overflow:visible}\n"]
		}]
	}],
	propDecorators: {
		url: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "url",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		linkClick: [{
			type: i0.Output,
			args: ["linkClick"]
		}],
		links$: [{
			type: i0.ViewChildren,
			args: [i0.forwardRef(() => RouterLinkActive), { isSignal: true }]
		}],
		labelTemplate: [{
			type: i0.ContentChild,
			args: ["labelTemplate", { isSignal: true }]
		}],
		linkTemplates: [{
			type: i0.ContentChildren,
			args: [i0.forwardRef(() => SidebarLinkTemplateDirective), { isSignal: true }]
		}]
	}
});
var SidebarWrapperComponent = class SidebarWrapperComponent {
	size = model("sm", ...ngDevMode ? [{ debugName: "size" }] : 	/* istanbul ignore next */ []);
	position = input("left", ...ngDevMode ? [{ debugName: "position" }] : 	/* istanbul ignore next */ []);
	theme = input("light", ...ngDevMode ? [{ debugName: "theme" }] : 	/* istanbul ignore next */ []);
	toggleMenu() {
		this.size.update((value) => value === "sm" ? "lg" : "sm");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: SidebarWrapperComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.1.6",
		type: SidebarWrapperComponent,
		isStandalone: true,
		selector: "cica-sidebar-wrapper",
		inputs: {
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			position: {
				classPropertyName: "position",
				publicName: "position",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			theme: {
				classPropertyName: "theme",
				publicName: "theme",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { size: "sizeChange" },
		ngImport: i0,
		template: "<div\n  class=\"sidebar sidebar-size-{{ size() }} sidebar-position-{{ position() }} sidebar-theme-{{\n    theme()\n  }}\"\n>\n  <button\n    (click)=\"toggleMenu()\"\n    class=\"sidebar-toggler\"\n    aria-label=\"Toggle Sidebar\"\n  >\n    <svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24\" viewBox=\"0 0 24 24\" width=\"24\" fill=\"currentColor\">\n  <path d=\"M7.41 8.59 12 13.17l4.59-4.58L18 10l-6 6-6-6z\"/>\n</svg>\n  </button>\n  <div class=\"sidebar-header\">\n    <div class=\"logo-image-wrapper-lg\">\n      <ng-content select=\".logo-image-lg\" />\n    </div>\n    <div class=\"logo-image-wrapper-sm\">\n      <ng-content select=\".logo-image-sm\" />\n    </div>\n  </div>\n  <nav class=\"sidebar-nav\">\n    <div class=\"nav-list primary-nav\">\n      <ng-content select=\"cica-sidebar-link\" />\n    </div>\n  </nav>\n</div>\n",
		styles: [":host{--header-height: 120px}:host .sidebar{position:fixed;box-sizing:border-box;top:0;left:0;z-index:1000;height:100vh;width:var(--sidebar-width, 250px);background-color:var(--sidebar-dark, #151a2d);transition:all .4s ease-in-out}:host .sidebar-header{position:relative;padding:.9375rem;display:flex;box-sizing:border-box;flex-direction:row;align-items:center;height:var(--sidebar-header-height, 120px);justify-content:space-between}:host .logo-image-wrapper-sm,:host .logo-image-wrapper-lg{height:100%;display:flex;align-items:center;justify-content:center}:host nav.sidebar-nav{width:100%;height:100%}:host .logo-image-wrapper-sm{display:none}:host .sidebar-toggler{position:absolute;display:flex;justify-content:center;align-items:center;right:0;top:var(--sidebar-header-height, 120px);transform:translate(50%,-50%);transition:left .3s ease;border:.125rem solid var(--sidebar-primary, rgb(86, 107, 223));border-radius:50%;z-index:2001}:host .sidebar-toggler svg{font-size:1.75rem;transition:.4s ease;transform:rotate(90deg)}:host .sidebar-nav .nav-list{display:flex;flex-direction:column;gap:.25rem;transition:.4s ease}:host .sidebar .sidebar-nav .primary-nav{overflow-y:auto;scrollbar-width:thin;scrollbar-color:transparent transparent}:host .sidebar.sidebar-position-left.sidebar-size-sm .sidebar-header,:host .sidebar:not(:hover).sidebar-size-md.sidebar-position-left .sidebar-header{flex-direction:column;align-items:center}:host .sidebar.sidebar-position-left.sidebar-size-sm .sidebar-toggler svg,:host .sidebar:not(:hover).sidebar-size-md.sidebar-position-left .sidebar-toggler svg{transform:rotate(270deg)}:host .sidebar.sidebar-position-left nav.sidebar-nav{display:block}:host .sidebar.sidebar-position-left nav.sidebar-nav .nav-list.primary-nav{height:calc(100% - var(--sidebar-header-height, 120px) - 20px)}:host .sidebar.sidebar-size-md.sidebar-position-left .sidebar-toggler{display:none}:host .sidebar.sidebar-position-left.sidebar-size-sm,:host .sidebar:not(:hover).sidebar-size-md.sidebar-position-left{width:var(--sidebar-small-width, 70px)}:host .sidebar.sidebar-position-left.sidebar-size-sm .logo-image-wrapper-lg,:host .sidebar:not(:hover).sidebar-size-md.sidebar-position-left .logo-image-wrapper-lg,:host .sidebar.sidebar-position-top .logo-image-wrapper-lg{display:none}:host .sidebar.sidebar-position-left.sidebar-size-sm .logo-image-wrapper-sm,:host .sidebar:not(:hover).sidebar-size-md.sidebar-position-left .logo-image-wrapper-sm,:host .sidebar.sidebar-position-top .logo-image-wrapper-sm{display:flex}:host .sidebar.sidebar-size-sm.sidebar-position-left .nav-list.primary-nav,:host .sidebar.sidebar-position-top .nav-list.primary-nav{overflow:visible}:host .sidebar.sidebar-position-top{--sidebar-width: 100vw;height:var(--top-sidebar-height, 60px);display:flex;flex-direction:row;align-items:center}:host .sidebar.sidebar-position-top .sidebar-toggler{display:none}:host .sidebar.sidebar-position-top nav.sidebar-nav{display:flex}:host .sidebar.sidebar-position-top nav.sidebar-nav .nav-list.primary-nav{flex-direction:row;align-items:center;width:100%}\n"]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.1.6",
	ngImport: i0,
	type: SidebarWrapperComponent,
	decorators: [{
		type: Component,
		args: [{
			imports: [],
			selector: "cica-sidebar-wrapper",
			template: "<div\n  class=\"sidebar sidebar-size-{{ size() }} sidebar-position-{{ position() }} sidebar-theme-{{\n    theme()\n  }}\"\n>\n  <button\n    (click)=\"toggleMenu()\"\n    class=\"sidebar-toggler\"\n    aria-label=\"Toggle Sidebar\"\n  >\n    <svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24\" viewBox=\"0 0 24 24\" width=\"24\" fill=\"currentColor\">\n  <path d=\"M7.41 8.59 12 13.17l4.59-4.58L18 10l-6 6-6-6z\"/>\n</svg>\n  </button>\n  <div class=\"sidebar-header\">\n    <div class=\"logo-image-wrapper-lg\">\n      <ng-content select=\".logo-image-lg\" />\n    </div>\n    <div class=\"logo-image-wrapper-sm\">\n      <ng-content select=\".logo-image-sm\" />\n    </div>\n  </div>\n  <nav class=\"sidebar-nav\">\n    <div class=\"nav-list primary-nav\">\n      <ng-content select=\"cica-sidebar-link\" />\n    </div>\n  </nav>\n</div>\n",
			styles: [":host{--header-height: 120px}:host .sidebar{position:fixed;box-sizing:border-box;top:0;left:0;z-index:1000;height:100vh;width:var(--sidebar-width, 250px);background-color:var(--sidebar-dark, #151a2d);transition:all .4s ease-in-out}:host .sidebar-header{position:relative;padding:.9375rem;display:flex;box-sizing:border-box;flex-direction:row;align-items:center;height:var(--sidebar-header-height, 120px);justify-content:space-between}:host .logo-image-wrapper-sm,:host .logo-image-wrapper-lg{height:100%;display:flex;align-items:center;justify-content:center}:host nav.sidebar-nav{width:100%;height:100%}:host .logo-image-wrapper-sm{display:none}:host .sidebar-toggler{position:absolute;display:flex;justify-content:center;align-items:center;right:0;top:var(--sidebar-header-height, 120px);transform:translate(50%,-50%);transition:left .3s ease;border:.125rem solid var(--sidebar-primary, rgb(86, 107, 223));border-radius:50%;z-index:2001}:host .sidebar-toggler svg{font-size:1.75rem;transition:.4s ease;transform:rotate(90deg)}:host .sidebar-nav .nav-list{display:flex;flex-direction:column;gap:.25rem;transition:.4s ease}:host .sidebar .sidebar-nav .primary-nav{overflow-y:auto;scrollbar-width:thin;scrollbar-color:transparent transparent}:host .sidebar.sidebar-position-left.sidebar-size-sm .sidebar-header,:host .sidebar:not(:hover).sidebar-size-md.sidebar-position-left .sidebar-header{flex-direction:column;align-items:center}:host .sidebar.sidebar-position-left.sidebar-size-sm .sidebar-toggler svg,:host .sidebar:not(:hover).sidebar-size-md.sidebar-position-left .sidebar-toggler svg{transform:rotate(270deg)}:host .sidebar.sidebar-position-left nav.sidebar-nav{display:block}:host .sidebar.sidebar-position-left nav.sidebar-nav .nav-list.primary-nav{height:calc(100% - var(--sidebar-header-height, 120px) - 20px)}:host .sidebar.sidebar-size-md.sidebar-position-left .sidebar-toggler{display:none}:host .sidebar.sidebar-position-left.sidebar-size-sm,:host .sidebar:not(:hover).sidebar-size-md.sidebar-position-left{width:var(--sidebar-small-width, 70px)}:host .sidebar.sidebar-position-left.sidebar-size-sm .logo-image-wrapper-lg,:host .sidebar:not(:hover).sidebar-size-md.sidebar-position-left .logo-image-wrapper-lg,:host .sidebar.sidebar-position-top .logo-image-wrapper-lg{display:none}:host .sidebar.sidebar-position-left.sidebar-size-sm .logo-image-wrapper-sm,:host .sidebar:not(:hover).sidebar-size-md.sidebar-position-left .logo-image-wrapper-sm,:host .sidebar.sidebar-position-top .logo-image-wrapper-sm{display:flex}:host .sidebar.sidebar-size-sm.sidebar-position-left .nav-list.primary-nav,:host .sidebar.sidebar-position-top .nav-list.primary-nav{overflow:visible}:host .sidebar.sidebar-position-top{--sidebar-width: 100vw;height:var(--top-sidebar-height, 60px);display:flex;flex-direction:row;align-items:center}:host .sidebar.sidebar-position-top .sidebar-toggler{display:none}:host .sidebar.sidebar-position-top nav.sidebar-nav{display:flex}:host .sidebar.sidebar-position-top nav.sidebar-nav .nav-list.primary-nav{flex-direction:row;align-items:center;width:100%}\n"]
		}]
	}],
	propDecorators: {
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["sizeChange"]
		}],
		position: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "position",
				required: false
			}]
		}],
		theme: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "theme",
				required: false
			}]
		}]
	}
});
export { SidebarLinkComponent, SidebarLinkTemplateDirective, SidebarWrapperComponent };

//# sourceMappingURL=cica-ui.mjs.map