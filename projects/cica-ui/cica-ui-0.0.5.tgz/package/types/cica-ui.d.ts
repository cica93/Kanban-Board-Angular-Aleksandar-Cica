import * as i0 from "@angular/core";
import { TemplateRef } from "@angular/core";
import { RouterLinkActive } from "@angular/router";
import { Subject } from "rxjs";
export declare class SidebarLinkTemplateDirective {
  templateRef: TemplateRef<any>;
  url: import("@angular/core").InputSignal<string>;
  label: import("@angular/core").InputSignal<string | undefined>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SidebarLinkTemplateDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SidebarLinkTemplateDirective, "[cicaSidebarLink]", never, {
    "url": {
      "alias": "url";
      "required": true;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export interface SidebarChildLink {
  url: string;
  label?: string;
}
export declare class SidebarLinkComponent {
  url: import("@angular/core").InputSignal<string | undefined>;
  label: import("@angular/core").InputSignal<string | undefined>;
  linkClick: import("@angular/core").OutputEmitterRef<void>;
  links$: import("@angular/core").Signal<readonly RouterLinkActive[]>;
  labelTemplate: import("@angular/core").Signal<TemplateRef<any> | undefined>;
  linkTemplates: import("@angular/core").Signal<readonly SidebarLinkTemplateDirective[]>;
  private readonly router;
  toggle: Subject<{
    event: "click" | "navigate";
    value?: boolean;
  }>;
  isOpen$: import("rxjs").Observable<boolean>;
  linkClicked(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<SidebarLinkComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SidebarLinkComponent, "cica-sidebar-link", never, {
    "url": {
      "alias": "url";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
  }, {
    "linkClick": "linkClick";
  }, ["labelTemplate", "linkTemplates"], [".link-icon"], true, never>;
}
export declare class SidebarWrapperComponent {
  size: import("@angular/core").ModelSignal<"sm" | "md" | "lg">;
  position: import("@angular/core").InputSignal<"top" | "left">;
  theme: import("@angular/core").InputSignal<"light" | "dark">;
  toggleMenu(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<SidebarWrapperComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SidebarWrapperComponent, "cica-sidebar-wrapper", never, {
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "position": {
      "alias": "position";
      "required": false;
      "isSignal": true;
    };
    "theme": {
      "alias": "theme";
      "required": false;
      "isSignal": true;
    };
  }, {
    "size": "sizeChange";
  }, never, [".logo-image-lg", ".logo-image-sm", "cica-sidebar-link"], true, never>;
}