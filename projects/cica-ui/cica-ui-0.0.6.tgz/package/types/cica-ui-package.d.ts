import * as i0 from "@angular/core";
import { ElementRef, InjectionToken, OnDestroy, OnInit, Renderer2, TemplateRef } from "@angular/core";
import { RouterLinkActive } from "@angular/router";
import { Observable, Subject } from "rxjs";
export declare class SidebarLinkTemplateDirective {
  templateRef: TemplateRef<any>;
  url: import("@angular/core").InputSignal<string>;
  label: import("@angular/core").InputSignal<string | undefined>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SidebarLinkTemplateDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SidebarLinkTemplateDirective, "[cicaSidebarLink]", never, {
    "url": {
      "alias": "url";
      "required": true;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export interface SidebarChildLink {
  url: string;
  label?: string;
}
export declare class SidebarLinkComponent {
  url: import("@angular/core").InputSignal<string | undefined>;
  label: import("@angular/core").InputSignal<string | undefined>;
  linkClick: import("@angular/core").OutputEmitterRef<void>;
  links$: import("@angular/core").Signal<readonly RouterLinkActive[]>;
  labelTemplate: import("@angular/core").Signal<TemplateRef<any> | undefined>;
  linkTemplates: import("@angular/core").Signal<readonly SidebarLinkTemplateDirective[]>;
  private readonly router;
  toggle: Subject<{
    event: "click" | "navigate";
    value?: boolean;
  }>;
  isOpen$: import("rxjs").Observable<boolean>;
  linkClicked(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<SidebarLinkComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SidebarLinkComponent, "cica-sidebar-link", never, {
    "url": {
      "alias": "url";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
  }, {
    "linkClick": "linkClick";
  }, ["labelTemplate", "linkTemplates"], [".link-icon"], true, never>;
}
export declare class SidebarWrapperComponent {
  size: import("@angular/core").ModelSignal<"sm" | "md" | "lg">;
  position: import("@angular/core").InputSignal<"top" | "left">;
  theme: import("@angular/core").InputSignal<"light" | "dark">;
  toggleMenu(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<SidebarWrapperComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SidebarWrapperComponent, "cica-sidebar-wrapper", never, {
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "position": {
      "alias": "position";
      "required": false;
      "isSignal": true;
    };
    "theme": {
      "alias": "theme";
      "required": false;
      "isSignal": true;
    };
  }, {
    "size": "sizeChange";
  }, never, [".logo-image-lg", ".logo-image-sm", "cica-sidebar-link"], true, never>;
}
export type Measure = 'px' | 'rem' | 'vh' | 'vw' | '%';
export type CssSize = `${number}${Measure}`;
export declare class BecomeVisibleDirective {
  private readonly hostElement;
  patentElement: import("@angular/core").InputSignal<HTMLElement | undefined>;
  rootMargin: import("@angular/core").InputSignal<`${number}px` | `${number}rem` | `${number}vh` | `${number}vw` | `${number}%`>;
  threshold: import("@angular/core").InputSignal<number>;
  becomeVisible: import("@angular/core").OutputEmitterRef<void>;
  private observer?;
  constructor();
  ngOnDestroy(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<BecomeVisibleDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<BecomeVisibleDirective, "[cicaBecomeVisible]", never, {
    "patentElement": {
      "alias": "patentElement";
      "required": false;
      "isSignal": true;
    };
    "rootMargin": {
      "alias": "rootMargin";
      "required": false;
      "isSignal": true;
    };
    "threshold": {
      "alias": "threshold";
      "required": false;
      "isSignal": true;
    };
  }, {
    "becomeVisible": "becomeVisible";
  }, never, never, true, never>;
}
export declare class DebounceInputDirective {
  debounceTime: import("@angular/core").InputSignal<number>;
  cicaDebounceInput: import("@angular/core").OutputEmitterRef<string>;
  private readonly el;
  private readonly debouncedValue;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<DebounceInputDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DebounceInputDirective, "[cicaDebounceInput]", never, {
    "debounceTime": {
      "alias": "debounceTime";
      "required": false;
      "isSignal": true;
    };
  }, {
    "cicaDebounceInput": "cicaDebounceInput";
  }, never, never, true, never>;
}
export declare const FETCH_DATA: InjectionToken<(filter: any, slot?: number) => Observable<any[]>>;
export declare class FetchDataDirective<T> implements OnInit {
  private readonly fetchData;
  private loading;
  private hasMore;
  private slot;
  fetchDisabed: import("@angular/core").InputSignal<boolean>;
  filterParams: import("@angular/core").InputSignal<any>;
  accumulatorCallBack: import("@angular/core").InputSignal<(acc: any[], curr: any[]) => any[]>;
  hasMoreCallBack: import("@angular/core").InputSignal<(value: any[]) => boolean>;
  cicaFetchData: import("@angular/core").OutputEmitterRef<T[]>;
  loadingChange: import("@angular/core").OutputEmitterRef<boolean>;
  becomeVisibleHtml: import("@angular/core").InputSignal<BecomeVisibleDirective>;
  filterParamsAsObservable$: Observable<any>;
  constructor();
  ngOnInit(): void;
  private setLoading;
  static ɵfac: i0.ɵɵFactoryDeclaration<FetchDataDirective<any>, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<FetchDataDirective<any>, "[cicaFetchData]", never, {
    "fetchDisabed": {
      "alias": "fetchDisabed";
      "required": false;
      "isSignal": true;
    };
    "filterParams": {
      "alias": "filterParams";
      "required": false;
      "isSignal": true;
    };
    "accumulatorCallBack": {
      "alias": "accumulatorCallBack";
      "required": false;
      "isSignal": true;
    };
    "hasMoreCallBack": {
      "alias": "hasMoreCallBack";
      "required": false;
      "isSignal": true;
    };
    "becomeVisibleHtml": {
      "alias": "becomeVisibleHtml";
      "required": true;
      "isSignal": true;
    };
  }, {
    "cicaFetchData": "cicaFetchData";
    "loadingChange": "loadingChange";
  }, never, never, true, never>;
}
export declare class FirstFocusDirective implements OnInit {
  private readonly hostElement;
  cicaFirstFocus: import("@angular/core").InputSignal<boolean>;
  ngOnInit(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<FirstFocusDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<FirstFocusDirective, "[cicaFirstFocus]", never, {
    "cicaFirstFocus": {
      "alias": "cicaFirstFocus";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class TooltipDirective implements OnDestroy {
  private readonly elementRef;
  private readonly renderer;
  cicaTooltip: import("@angular/core").InputSignal<string>;
  tooltipPosition: import("@angular/core").InputSignal<"top" | "left" | "bottom" | "right">;
  private tooltipElement?;
  private showTimeout?;
  private hideTimeout?;
  constructor(elementRef: ElementRef<HTMLElement>, renderer: Renderer2);
  onMouseEnter(): void;
  onMouseLeave(): void;
  private show;
  private hide;
  private positionTooltip;
  private clearTimeouts;
  ngOnDestroy(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<TooltipDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<TooltipDirective, "[cicaTooltip]", never, {
    "cicaTooltip": {
      "alias": "cicaTooltip";
      "required": true;
      "isSignal": true;
    };
    "tooltipPosition": {
      "alias": "tooltipPosition";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class VisiblilityChangeDirective implements OnDestroy {
  private readonly hostElement;
  patentElement: import("@angular/core").InputSignal<HTMLElement | undefined>;
  rootMargin: import("@angular/core").InputSignal<`${number}px` | `${number}rem` | `${number}vh` | `${number}vw` | `${number}%`>;
  threshold: import("@angular/core").InputSignal<number>;
  cicaVisiblilityChange: import("@angular/core").OutputEmitterRef<boolean>;
  observer?: IntersectionObserver;
  constructor();
  ngOnDestroy(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<VisiblilityChangeDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<VisiblilityChangeDirective, "[cicaVisiblilityChange]", never, {
    "patentElement": {
      "alias": "patentElement";
      "required": false;
      "isSignal": true;
    };
    "rootMargin": {
      "alias": "rootMargin";
      "required": false;
      "isSignal": true;
    };
    "threshold": {
      "alias": "threshold";
      "required": false;
      "isSignal": true;
    };
  }, {
    "cicaVisiblilityChange": "cicaVisiblilityChange";
  }, never, never, true, never>;
}
export declare function subscribeOnElementAppear(config: {
  root?: HTMLElement;
  rootMargin?: string;
  threshold?: number;
  observerElement: Element;
  callBackFunction: (isIntersecting: boolean) => void;
}): IntersectionObserver;