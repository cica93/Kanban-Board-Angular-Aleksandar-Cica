import * as i0 from "@angular/core";
import { ApplicationRef, ComponentRef, EnvironmentInjector, InjectionToken, Injector, InputSignal, OnDestroy, OnInit, TemplateRef, Type, ViewContainerRef } from "@angular/core";
import { RouterLinkActive } from "@angular/router";
import { Observable, Subject } from "rxjs";
import { FieldTree, FormValueControl } from "@angular/forms/signals";
export declare class SidebarLinkTemplateDirective {
  templateRef: TemplateRef<any>;
  url: import("@angular/core").InputSignal<string>;
  label: import("@angular/core").InputSignal<string | undefined>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SidebarLinkTemplateDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SidebarLinkTemplateDirective, "[cicaSidebarLink]", never, {
    "url": {
      "alias": "url";
      "required": true;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export interface SidebarChildLink {
  url: string;
  label?: string;
}
export declare class SidebarLinkComponent {
  url: import("@angular/core").InputSignal<string | undefined>;
  label: import("@angular/core").InputSignal<string | undefined>;
  linkClick: import("@angular/core").OutputEmitterRef<void>;
  links$: import("@angular/core").Signal<readonly RouterLinkActive[]>;
  labelTemplate: import("@angular/core").Signal<TemplateRef<any> | undefined>;
  linkTemplates: import("@angular/core").Signal<readonly SidebarLinkTemplateDirective[]>;
  private readonly router;
  toggle: Subject<{
    event: "click" | "navigate";
    value?: boolean;
  }>;
  isOpen$: import("rxjs").Observable<boolean>;
  linkClicked(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<SidebarLinkComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SidebarLinkComponent, "cica-sidebar-link", never, {
    "url": {
      "alias": "url";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
  }, {
    "linkClick": "linkClick";
  }, ["labelTemplate", "linkTemplates"], [".link-icon"], true, never>;
}
export declare class SidebarWrapperComponent {
  size: import("@angular/core").ModelSignal<"sm" | "md" | "lg">;
  position: import("@angular/core").InputSignal<"top" | "left">;
  showToggleButton: import("@angular/core").InputSignal<boolean>;
  toggleMenu(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<SidebarWrapperComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SidebarWrapperComponent, "cica-sidebar-wrapper", never, {
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "position": {
      "alias": "position";
      "required": false;
      "isSignal": true;
    };
    "showToggleButton": {
      "alias": "showToggleButton";
      "required": false;
      "isSignal": true;
    };
  }, {
    "size": "sizeChange";
  }, never, [".logo-image-lg", ".logo-image-sm", "cica-sidebar-link"], true, never>;
}
export declare class InputComponent implements FormValueControl<string | number | boolean | null> {
  label: import("@angular/core").InputSignal<string | undefined>;
  placeholder: import("@angular/core").InputSignal<string | undefined>;
  errorMessage: import("@angular/core").InputSignal<string | undefined>;
  labelPosition: import("@angular/core").InputSignal<"top" | "left">;
  value: import("@angular/core").ModelSignal<string | number | boolean | null>;
  disabled: import("@angular/core").InputSignal<boolean>;
  hidden: import("@angular/core").InputSignal<boolean>;
  invalid: import("@angular/core").InputSignal<boolean>;
  touched: import("@angular/core").InputSignal<boolean>;
  showClearIcon: import("@angular/core").InputSignal<boolean>;
  showTogglePassword: import("@angular/core").InputSignal<boolean>;
  required: import("@angular/core").InputSignal<boolean>;
  inputType: import("@angular/core").InputSignal<"number" | "text" | "password" | "checkbox">;
  labelClick(target: EventTarget | null): void;
  clear(): void;
  togglePassword(target: EventTarget | null): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<InputComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<InputComponent, "cica-input", never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "errorMessage": {
      "alias": "errorMessage";
      "required": false;
      "isSignal": true;
    };
    "labelPosition": {
      "alias": "labelPosition";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "hidden": {
      "alias": "hidden";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "touched": {
      "alias": "touched";
      "required": false;
      "isSignal": true;
    };
    "showClearIcon": {
      "alias": "showClearIcon";
      "required": false;
      "isSignal": true;
    };
    "showTogglePassword": {
      "alias": "showTogglePassword";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "inputType": {
      "alias": "inputType";
      "required": false;
      "isSignal": true;
    };
  }, {
    "value": "valueChange";
  }, never, [".left-icon", ".right-icon"], true, never>;
}
export interface SubmitForm<INIT_VALUE = any, FORM_VALUE = any> {
  initValue: InputSignal<INIT_VALUE | null | undefined>;
  form: FieldTree<FORM_VALUE>;
  onClose: Subject<boolean>;
}
export declare const SUBMIT_FORM_TOKEN_LOAD: InjectionToken<() => Promise<Type<SubmitForm>>>;
export declare const SUBMIT_FORM_TOKEN: InjectionToken<Type<SubmitForm<any, any>>>;
export declare class ModalDirective {
  private readonly appRef;
  private readonly environmentInjector;
  private readonly injector;
  private readonly modalService;
  initValue: InputSignal<any>;
  cicaModal: InputSignal<string | TemplateRef<any>>;
  cancelLabel: InputSignal<string | undefined>;
  confirmLabel: InputSignal<string | undefined>;
  showWarningIcon: InputSignal<boolean>;
  fullHeight: InputSignal<boolean>;
  modalPosition: InputSignal<"left" | "center" | "right">;
  isDelete: InputSignal<boolean>;
  headerText: InputSignal<string | undefined>;
  onConfirm: import("@angular/core").OutputEmitterRef<{
    componentRef: ComponentRef<ModalComponent>;
    appRef: ApplicationRef;
  }>;
  onSuccess: import("@angular/core").OutputEmitterRef<any>;
  modalOpenEvent: import("@angular/core").OutputEmitterRef<ComponentRef<ModalComponent>>;
  onCancel: import("@angular/core").OutputEmitterRef<void>;
  componentRef?: ComponentRef<ModalComponent>;
  private submitFormComponentRef?;
  handleClick(): Promise<void>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ModalDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ModalDirective, "[cicaModal]", never, {
    "initValue": {
      "alias": "initValue";
      "required": false;
      "isSignal": true;
    };
    "cicaModal": {
      "alias": "cicaModal";
      "required": true;
      "isSignal": true;
    };
    "cancelLabel": {
      "alias": "cancelLabel";
      "required": false;
      "isSignal": true;
    };
    "confirmLabel": {
      "alias": "confirmLabel";
      "required": false;
      "isSignal": true;
    };
    "showWarningIcon": {
      "alias": "showWarningIcon";
      "required": false;
      "isSignal": true;
    };
    "fullHeight": {
      "alias": "fullHeight";
      "required": false;
      "isSignal": true;
    };
    "modalPosition": {
      "alias": "modalPosition";
      "required": false;
      "isSignal": true;
    };
    "isDelete": {
      "alias": "isDelete";
      "required": false;
      "isSignal": true;
    };
    "headerText": {
      "alias": "headerText";
      "required": false;
      "isSignal": true;
    };
  }, {
    "onConfirm": "onConfirm";
    "onSuccess": "onSuccess";
    "modalOpenEvent": "modalOpenEvent";
    "onCancel": "onCancel";
  }, never, never, true, never>;
}
export type ModalPosition = 'left' | 'center' | 'right';
export interface ModalOptions {
  cancelLabel?: string;
  confirmLabel?: string;
  headerText?: string;
  fullHeight?: boolean;
  initValue?: any;
  modalPosition: ModalPosition;
  showWarningIcon?: boolean;
  content?: string | TemplateRef<any>;
}
export declare class ModalService {
  private readonly appRef;
  private readonly environmentInjector;
  private readonly injector;
  openEditModal(config: {
    environmentInjector?: EnvironmentInjector;
    injector?: Injector;
    modalOptions: ModalOptions;
  }): Promise<{
    componentRef: ComponentRef<ModalComponent>;
    submitFormRef: ComponentRef<SubmitForm<any, any>>;
  }>;
  openDeleteModal(config: {
    environmentInjector?: EnvironmentInjector;
    injector?: Injector;
    modalOptions: ModalOptions;
  }): ComponentRef<ModalComponent>;
  close(componentRef: ComponentRef<ModalComponent>): void;
  private attachView;
  static ɵfac: i0.ɵɵFactoryDeclaration<ModalService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare function destroy<T>(appRef: ApplicationRef, componentRef: ComponentRef<T>): void;
export declare function templateToNodes<T>(template: TemplateRef<T> | string, viewContainer: ViewContainerRef): Node[];
export declare function closeModal(appRef: ApplicationRef, ref: ComponentRef<ModalComponent> | undefined, submitFormComponentRef?: ComponentRef<SubmitForm<any, any>>): void;
export declare function createSubmitForm(component: Type<SubmitForm>, viewContainer: ViewContainerRef, injector: Injector, environmentInjector: EnvironmentInjector, initValue: any): ComponentRef<SubmitForm>;
export declare class ModalComponent {
  cancelLabel: import("@angular/core").InputSignal<string | undefined>;
  confirmLabel: import("@angular/core").InputSignal<string | undefined>;
  fullHeight: import("@angular/core").InputSignal<boolean>;
  modalPosition: import("@angular/core").InputSignal<ModalPosition>;
  showWarningIcon: import("@angular/core").InputSignal<boolean>;
  headerText: import("@angular/core").InputSignal<string | undefined>;
  submitFormType: import("@angular/core").InputSignal<Type<SubmitForm<any, any>> | null>;
  initValue: import("@angular/core").InputSignal<unknown>;
  onConfirm: import("@angular/core").OutputEmitterRef<void>;
  onCancel: import("@angular/core").OutputEmitterRef<void>;
  onSuccess: import("@angular/core").OutputEmitterRef<unknown>;
  private formHost;
  private submitFormRef?;
  private readonly injector;
  private readonly environmentInjector;
  ngAfterViewInit(): void;
  confirm(): void;
  cancel(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ModalComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ModalComponent, "cica-modal", never, {
    "cancelLabel": {
      "alias": "cancelLabel";
      "required": false;
      "isSignal": true;
    };
    "confirmLabel": {
      "alias": "confirmLabel";
      "required": false;
      "isSignal": true;
    };
    "fullHeight": {
      "alias": "fullHeight";
      "required": false;
      "isSignal": true;
    };
    "modalPosition": {
      "alias": "modalPosition";
      "required": false;
      "isSignal": true;
    };
    "showWarningIcon": {
      "alias": "showWarningIcon";
      "required": false;
      "isSignal": true;
    };
    "headerText": {
      "alias": "headerText";
      "required": false;
      "isSignal": true;
    };
    "submitFormType": {
      "alias": "submitFormType";
      "required": false;
      "isSignal": true;
    };
    "initValue": {
      "alias": "initValue";
      "required": false;
      "isSignal": true;
    };
  }, {
    "onConfirm": "onConfirm";
    "onCancel": "onCancel";
    "onSuccess": "onSuccess";
  }, never, ["*"], true, never>;
}
export declare class CardComponent {
  cardTitle: import("@angular/core").InputSignal<string>;
  cardSubtitle: import("@angular/core").InputSignal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<CardComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CardComponent, "cica-card", never, {
    "cardTitle": {
      "alias": "cardTitle";
      "required": true;
      "isSignal": true;
    };
    "cardSubtitle": {
      "alias": "cardSubtitle";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["[slot=cardTitle]", "[slot=cardSubtitle]", "[slot=conrent]"], true, never>;
}
export declare class MenuButtonComponent {
  isOpen: import("@angular/core").InputSignal<boolean>;
  isHidden: import("@angular/core").InputSignal<boolean>;
  dropdownTrigger: import("@angular/core").OutputEmitterRef<void>;
  static ɵfac: i0.ɵɵFactoryDeclaration<MenuButtonComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MenuButtonComponent, "cica-menu-button", never, {
    "isOpen": {
      "alias": "isOpen";
      "required": false;
      "isSignal": true;
    };
    "isHidden": {
      "alias": "isHidden";
      "required": false;
      "isSignal": true;
    };
  }, {
    "dropdownTrigger": "dropdownTrigger";
  }, never, ["*"], true, never>;
}
export declare class ListComponent {
  static ɵfac: i0.ɵɵFactoryDeclaration<ListComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ListComponent, "cica-ui-list", never, {}, {}, never, ["*"], true, never>;
}
export declare class ListItemComponent {
  button: import("@angular/core").InputSignal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ListItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ListItemComponent, "cica-ui-list-item", never, {
    "button": {
      "alias": "button";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["[slot=start]", "*", "[slot=end]"], true, never>;
}
export declare class CollectionsComponent {
  items: import("@angular/core").InputSignal<any[]>;
  columns: import("@angular/core").InputSignal<number>;
  notFoundText: import("@angular/core").InputSignal<string | undefined>;
  tempate: import("@angular/core").Signal<TemplateRef<any> | undefined>;
  static ɵfac: i0.ɵɵFactoryDeclaration<CollectionsComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CollectionsComponent, "cica-collections", never, {
    "items": {
      "alias": "items";
      "required": true;
      "isSignal": true;
    };
    "columns": {
      "alias": "columns";
      "required": false;
      "isSignal": true;
    };
    "notFoundText": {
      "alias": "notFoundText";
      "required": false;
      "isSignal": true;
    };
  }, {}, ["tempate"], never, true, never>;
}
export declare class TooltipDirective implements OnDestroy {
  cicaTooltip: import("@angular/core").InputSignal<string | TemplateRef<any>>;
  customTrigger: import("@angular/core").InputSignal<boolean>;
  tooltipPosition: import("@angular/core").InputSignal<"top" | "left" | "right" | "bottom">;
  private tooltipElement;
  private tooltipView?;
  private showTimeout?;
  private hideTimeout?;
  private readonly elementRef;
  private readonly renderer;
  private readonly viewContainerRef;
  onMouseEnter(): void;
  onMouseLeave(): void;
  show(): void;
  hide(): void;
  private positionTooltip;
  private clearTimeouts;
  ngOnDestroy(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<TooltipDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<TooltipDirective, "[cicaTooltip]", ["cicaTooltip"], {
    "cicaTooltip": {
      "alias": "cicaTooltip";
      "required": true;
      "isSignal": true;
    };
    "customTrigger": {
      "alias": "customTrigger";
      "required": false;
      "isSignal": true;
    };
    "tooltipPosition": {
      "alias": "tooltipPosition";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class DebounceInputDirective {
  debounceTime: import("@angular/core").InputSignal<number>;
  cicaDebounceInput: import("@angular/core").OutputEmitterRef<string>;
  private readonly el;
  private readonly input;
  private readonly debouncedValue;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<DebounceInputDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DebounceInputDirective, "[cicaDebounceInput]", never, {
    "debounceTime": {
      "alias": "debounceTime";
      "required": false;
      "isSignal": true;
    };
  }, {
    "cicaDebounceInput": "cicaDebounceInput";
  }, never, never, true, never>;
}
export type Measure = 'px' | 'rem' | 'vh' | 'vw' | '%';
export type CssSize = `${number}${Measure}`;
export declare class BecomeVisibleDirective {
  private readonly hostElement;
  patentElement: import("@angular/core").InputSignal<HTMLElement | undefined>;
  rootMargin: import("@angular/core").InputSignal<`${number}px` | `${number}rem` | `${number}vh` | `${number}vw` | `${number}%`>;
  threshold: import("@angular/core").InputSignal<number>;
  cicaBecomeVisible: import("@angular/core").OutputEmitterRef<void>;
  private observer?;
  constructor();
  ngOnDestroy(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<BecomeVisibleDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<BecomeVisibleDirective, "[cicaBecomeVisible]", never, {
    "patentElement": {
      "alias": "patentElement";
      "required": false;
      "isSignal": true;
    };
    "rootMargin": {
      "alias": "rootMargin";
      "required": false;
      "isSignal": true;
    };
    "threshold": {
      "alias": "threshold";
      "required": false;
      "isSignal": true;
    };
  }, {
    "cicaBecomeVisible": "cicaBecomeVisible";
  }, never, never, true, never>;
}
export declare const FETCH_DATA: InjectionToken<(filter: any, slot?: number) => Observable<any[]>>;
export declare class FetchDataDirective<T> implements OnInit {
  private readonly fetchData;
  private loading;
  private hasMore;
  private slot;
  fetchDisabed: import("@angular/core").InputSignal<boolean>;
  filterParams: import("@angular/core").InputSignal<any>;
  accumulatorCallBack: import("@angular/core").InputSignal<(acc: any[], curr: any[]) => any[]>;
  hasMoreCallBack: import("@angular/core").InputSignal<(value: any[]) => boolean>;
  cicaFetchData: import("@angular/core").OutputEmitterRef<T[]>;
  loadingChange: import("@angular/core").OutputEmitterRef<boolean>;
  becomeVisibleHtml: import("@angular/core").InputSignal<BecomeVisibleDirective>;
  filterParamsAsObservable$: Observable<any>;
  constructor();
  ngOnInit(): void;
  private setLoading;
  static ɵfac: i0.ɵɵFactoryDeclaration<FetchDataDirective<any>, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<FetchDataDirective<any>, "[cicaFetchData]", never, {
    "fetchDisabed": {
      "alias": "fetchDisabed";
      "required": false;
      "isSignal": true;
    };
    "filterParams": {
      "alias": "filterParams";
      "required": false;
      "isSignal": true;
    };
    "accumulatorCallBack": {
      "alias": "accumulatorCallBack";
      "required": false;
      "isSignal": true;
    };
    "hasMoreCallBack": {
      "alias": "hasMoreCallBack";
      "required": false;
      "isSignal": true;
    };
    "becomeVisibleHtml": {
      "alias": "becomeVisibleHtml";
      "required": true;
      "isSignal": true;
    };
  }, {
    "cicaFetchData": "cicaFetchData";
    "loadingChange": "loadingChange";
  }, never, never, true, never>;
}
export declare class FirstFocusDirective implements OnInit {
  private readonly hostElement;
  cicaFirstFocus: import("@angular/core").InputSignal<boolean>;
  ngOnInit(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<FirstFocusDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<FirstFocusDirective, "[cicaFirstFocus]", never, {
    "cicaFirstFocus": {
      "alias": "cicaFirstFocus";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class VisiblilityChangeDirective implements OnDestroy {
  private readonly hostElement;
  patentElement: import("@angular/core").InputSignal<HTMLElement | undefined>;
  rootMargin: import("@angular/core").InputSignal<`${number}px` | `${number}rem` | `${number}vh` | `${number}vw` | `${number}%`>;
  threshold: import("@angular/core").InputSignal<number>;
  cicaVisiblilityChange: import("@angular/core").OutputEmitterRef<boolean>;
  observer?: IntersectionObserver;
  constructor();
  ngOnDestroy(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<VisiblilityChangeDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<VisiblilityChangeDirective, "[cicaVisiblilityChange]", never, {
    "patentElement": {
      "alias": "patentElement";
      "required": false;
      "isSignal": true;
    };
    "rootMargin": {
      "alias": "rootMargin";
      "required": false;
      "isSignal": true;
    };
    "threshold": {
      "alias": "threshold";
      "required": false;
      "isSignal": true;
    };
  }, {
    "cicaVisiblilityChange": "cicaVisiblilityChange";
  }, never, never, true, never>;
}
export declare function subscribeOnElementAppear(config: {
  root?: HTMLElement;
  rootMargin?: string;
  threshold?: number;
  observerElement: Element;
  callBackFunction: (isIntersecting: boolean) => void;
}): IntersectionObserver;
export declare class ToastService {
  private readonly maxStack;
  private readonly position;
  private readonly container;
  private readonly icons;
  constructor();
  success(message: string, title?: string, duration?: number): void;
  error(message: string, title?: string, duration?: number): void;
  warning(message: string, title?: string, duration?: number): void;
  info(message: string, title?: string, duration?: number): void;
  show(type: 'success' | 'error' | 'warning' | 'info', message: string, title?: string, duration?: number): HTMLDivElement;
  dismiss(duration: number, t?: Element): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ToastService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}