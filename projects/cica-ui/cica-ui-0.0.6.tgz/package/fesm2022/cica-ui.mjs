import * as i0 from "@angular/core";
import { ApplicationRef, Component, Directive, ElementRef, EnvironmentInjector, InjectionToken, Injector, Renderer2, Service, TemplateRef, ViewChild, ViewContainerRef, contentChild, contentChildren, createComponent, effect, inject, input, inputBinding, model, output, viewChildren } from "@angular/core";
import { AsyncPipe, NgTemplateOutlet } from "@angular/common";
import { outputToObservable, takeUntilDestroyed, toObservable, toSignal } from "@angular/core/rxjs-interop";
import { Router, RouterLink, RouterLinkActive } from "@angular/router";
import { Subject, catchError, combineLatest, debounceTime, distinctUntilChanged, filter, fromEvent, map, merge, of, scan, startWith, switchMap, tap } from "rxjs";
import { submit } from "@angular/forms/signals";
var SidebarLinkTemplateDirective = class SidebarLinkTemplateDirective {
	templateRef = inject(TemplateRef);
	url = input.required(...ngDevMode ? [{ debugName: "url" }] : 	/* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : 	/* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: SidebarLinkTemplateDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.1.6",
		type: SidebarLinkTemplateDirective,
		isStandalone: true,
		selector: "[cicaSidebarLink]",
		inputs: {
			url: {
				classPropertyName: "url",
				publicName: "url",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.1.6",
	ngImport: i0,
	type: SidebarLinkTemplateDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[cicaSidebarLink]" }]
	}],
	propDecorators: {
		url: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "url",
				required: true
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}]
	}
});
var SidebarLinkComponent = class SidebarLinkComponent {
	url = input(...ngDevMode ? [void 0, { debugName: "url" }] : 	/* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : 	/* istanbul ignore next */ []);
	linkClick = output();
	links$ = viewChildren(RouterLinkActive, ...ngDevMode ? [{ debugName: "links$" }] : 	/* istanbul ignore next */ []);
	labelTemplate = contentChild("labelTemplate", ...ngDevMode ? [{ debugName: "labelTemplate" }] : 	/* istanbul ignore next */ []);
	linkTemplates = contentChildren(SidebarLinkTemplateDirective, ...ngDevMode ? [{ debugName: "linkTemplates" }] : 	/* istanbul ignore next */ []);
	router = inject(Router);
	toggle = new Subject();
	isOpen$ = merge(toObservable(this.links$).pipe(switchMap((links) => combineLatest(links.map((e) => e.isActiveChange.asObservable().pipe(startWith(false)))).pipe(map((isActiveAnyLink) => ({
		event: "navigate",
		value: isActiveAnyLink.some(Boolean)
	}))))), this.toggle.asObservable()).pipe(scan((acc, cur) => {
		if (cur.event === "click") return !acc;
		return cur?.value ?? false;
	}, false));
	linkClicked() {
		if (this.url()) this.router.navigate([this.url()]);
		this.linkClick.emit();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: SidebarLinkComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.1.6",
		type: SidebarLinkComponent,
		isStandalone: true,
		selector: "cica-sidebar-link",
		inputs: {
			url: {
				classPropertyName: "url",
				publicName: "url",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { linkClick: "linkClick" },
		queries: [{
			propertyName: "labelTemplate",
			first: true,
			predicate: ["labelTemplate"],
			descendants: true,
			isSignal: true
		}, {
			propertyName: "linkTemplates",
			predicate: SidebarLinkTemplateDirective,
			isSignal: true
		}],
		viewQueries: [{
			propertyName: "links$",
			predicate: RouterLinkActive,
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "@let hasChildren = linkTemplates().length > 0;\n<div\n  class=\"nav-item\"\n  (click)=\"linkClicked()\"\n  [class.dropdown-container]=\"hasChildren\"\n>\n  <a\n    (click)=\"toggle.next({ event: 'click' })\"\n    class=\"nav-link\"\n    [class.dropdown-toggle]=\"hasChildren\"\n  >\n    <ng-content select=\".link-icon\" />\n    <span class=\"nav-label\"  [class.no-content]=\"!labelTemplate() && !label()\">\n      @if (labelTemplate(); as template) {\n    <ng-container\n      [ngTemplateOutlet]=\"template\"\n    />\n  } @else {\n    {{label()}}\n  }\n    </span>\n    @if (hasChildren) {\n      <span class=\"dropdown-icon\">\n\n<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24\" viewBox=\"0 0 24 24\" width=\"24\" fill=\"currentColor\">\n  <path d=\"M7.41 8.59 12 13.17l4.59-4.58L18 10l-6 6-6-6z\"/>\n</svg>\n\n      </span>\n    }\n  </a>\n  <div\n    class=\"dropdown-menu\"\n    [class.open]=\"isOpen$ | async\"\n  >\n    <div class=\"\">\n      @for (childLink of linkTemplates(); track childLink.url()) {\n        <div class=\"nav-item\">\n          <a\n            [routerLink]=\"childLink.url()\"\n            routerLinkActive=\"active\"\n            class=\"nav-link dropdown-link\"\n            >\n            <ng-template [ngTemplateOutlet]=\"childLink.templateRef\"></ng-template\n          ></a>\n        </div>\n      } @empty {\n        <div class=\"nav-item\">\n          <a\n            [routerLink]=\"url()\"\n            routerLinkActive=\"active\"\n            class=\"nav-link dropdown-link\"\n            [class.no-content]=\"!labelTemplate() && !label()\"\n            >@if (labelTemplate(); as template) {\n              <ng-container [ngTemplateOutlet]=\"template\" />\n            } @else {\n              {{ label() }}\n            }</a\n          >\n        </div>\n      }\n    </div>\n  </div>\n</div>\n",
		styles: [":host .nav-item{margin:0 .5rem}:host .nav-item:hover:has(.dropdown-menu a.active){border-left:none}:host .no-content{display:none}:host .nav-item .nav-link{color:var(--sidebar-light, #eef2ff);display:flex;gap:var(--navigation-link-space, .75rem);white-space:nowrap;border-radius:.5rem;padding:var(--navigation-link-space, .75rem);align-items:center;text-decoration:none;border:1px solid var(--sidebar-dark, #151a2d);transition:.4s ease;cursor:pointer}:host .nav-item:is(:hover,.open)>.nav-link:not(.dropdown-title){color:var(--sidebar-dark, #151a2d);background-color:var(--sidebar-light, #eef2ff)}:host .nav-item:has(.dropdown-menu):has(a.active) .nav-link:not(.dropdown-link),:host a.active{font-weight:700}:host .nav-link .nav-label{transition:opacity 3s ease;width:100%}:host .dropdown-icon{transition:transform .3s ease;transform:rotate(90deg)}:host .dropdown-toggle{cursor:pointer}:host-context(.sidebar-size.sm.sidebar-position-left) .dropdown-menu .nav-link,:host-context(.sidebar:not(:hover).sidebar-size-md.sidebar-position-left) .dropdown-menu .nav-link,:host-context(.sidebar.sidebar-position-top) .dropdown-menu .nav-link{min-width:160px}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-item .dropdown-menu{position:absolute;width:200px;height:auto!important;overflow:visible;opacity:1;z-index:1001;pointer-events:auto;background-color:var(--sidebar-dark, #151a2d);border-top-right-radius:.5rem;border-bottom-right-radius:.5rem}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) :host:hover>.dropdown-menu{display:block}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) :host:hover>.dropdown-menu:has(.no-content),:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-link.dropdown-link.no-content{display:none}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-item>.dropdown-menu{left:100%;top:0}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-link :where(.nav-label,.dropdown-icon),:host-context(.sidebar:not(:hover).sidebar-size-md.sidebar-position-left) .nav-link :where(.nav-label,.dropdown-icon){display:none!important}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-item .dropdown-menu,:host-context(.sidebar:not(:hover).sidebar-size-md.sidebar-position-left) .nav-item .dropdown-menu{display:none}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-item .nav-link,:host-context(.sidebar:not(:hover).sidebar-size-md.sidebar-position-left) .nav-item .nav-link{justify-content:center}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .dropdown-menu .nav-item .nav-link,:host-context(.sidebar:not(:hover).sidebar-size-md.sidebar-position-left) .dropdown-menu .nav-item .nav-link{justify-content:start}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .dropdown-menu .nav-item .dropdown-title,:host-context(.sidebar:not(:hover).sidebar-size-md.sidebar-position-left) .dropdown-menu .nav-item .dropdown-title{display:block}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-link .dropdown-icon,:host-context(.sidebar:not(:hover).sidebar-size-md.sidebar-position-left) .nav-link .dropdown-icon{transition:opacity .3s 0s easy}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .dropdown-menu:has(.dropdown-link),:host-context(.sidebar:not(:hover).sidebar-size-md.sidebar-position-left) .dropdown-menu:has(.dropdown-link){padding:var(--dropdown-menu-padding, .5rem)}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-item:hover>.dropdown-menu,:host-context(.sidebar:not(:hover).sidebar-size-md.sidebar-position-left) .nav-item:hover>.dropdown-menu{display:block;opacity:1;pointer-events:auto;transition:all .4s ease}.nav-item{position:relative}.dropdown-menu{height:0;overflow-y:hidden;padding-left:1rem;transition:height .4s ease}.dropdown-content{min-height:0;overflow:hidden}.dropdown-menu .nav-item .nav-link,.dropdown-menu .nav-item .nav-link .dropdown-title{color:var(--sidebar-light, #eef2ff);padding:.5rem .75rem}.dropdown-menu .nav-item .nav-link .dropdown-title{display:none}.dropdown-menu:has(.dropdown-link) .nav-item .dropdown-title{font-weight:500;padding:.5rem .75rem}:host-context(.sidebar.sidebar-position-top) .dropdown-menu{border-radius:.5rem;padding:.5rem 0}:host-context(.sidebar.sidebar-position-top) .nav-item.dropdown-container{padding:.25rem 0}:host-context(.sidebar.sidebar-position-top) .nav-item:has(.dropdown-menu):has(a.active):not(:hover) .nav-link:not(.dropdown-link){border-bottom-left-radius:0;border-bottom-right-radius:0;border-bottom:.125rem solid var(--sidebar-primary, rgb(86, 107, 223))}:host-context(.sidebar.sidebar-position-top) .nav-item.dropdown-container:hover>.dropdown-menu{display:block;height:auto;overflow:visible;opacity:1;pointer-events:auto}:host-context(.sidebar.sidebar-position-top) .dropdown-container .dropdown-menu.open{display:block;height:auto;overflow:visible}:host-context(.sidebar.sidebar-position-top) .dropdown-menu{position:absolute;bottom:0;transform:translateY(100%);left:0;z-index:1001;min-width:100%;padding-left:0;background-color:var(--sidebar-dark, #151a2d);display:none}:host-context(.sidebar.sidebar-position-top) .dropdown-icon{display:none}:host-context(.sidebar.sidebar-position-left) .nav-item:has(.dropdown-menu a.active){border-left:.25rem solid var(--sidebar-primary, rgb(86, 107, 223))}:host-context(.sidebar.sidebar-position-left) .nav-item:has(.dropdown-menu a.active){margin-left:.25rem}:host-context(.sidebar.sidebar-position-left) .dropdown-container .dropdown-menu.open{height:auto;overflow:visible}:host-context(.sidebar.sidebar-position-left) .dropdown-container.open .dropdown-icon{transform:rotate(180deg)}:host-context(.sidebar.sidebar-position-left) .nav-item:has(.dropdown-menu.open) .dropdown-icon{transform:rotate(0)}:host-context(.sidebar.sidebar-size-md.sidebar-position-left:hover) .dropdown-menu,:host-context(.sidebar.sidebar-size-lg.sidebar-position-left) .dropdown-menu{height:0;overflow:hidden;interpolate-size:allow-keywords;transition:height .4s ease}:host-context(.sidebar.sidebar-size-md.sidebar-position-left:hover) .nav-item .dropdown-menu a.nav-link.dropdown-link.active,:host-context(.sidebar.sidebar-size-lg.sidebar-position-left) .nav-item .dropdown-menu a.nav-link.dropdown-link.active{border-left:none}:host-context(.sidebar.sidebar-size-md.sidebar-position-left:hover) .nav-link :where(.nav-label,.dropdown-icon),:host-context(.sidebar.sidebar-size-lg.sidebar-position-left) .nav-link :where(.nav-label,.dropdown-icon){display:inline}:host-context(.sidebar.sidebar-size-md.sidebar-position-left:hover) .dropdown-menu,:host-context(.sidebar.sidebar-size-lg.sidebar-position-left) .dropdown-menu{position:static;opacity:1;pointer-events:auto;border-radius:0;background:transparent}:host-context(.sidebar.sidebar-size-md.sidebar-position-left:hover) .dropdown-container .dropdown-menu.open,:host-context(.sidebar.sidebar-size-lg.sidebar-position-left) .dropdown-container .dropdown-menu.open{display:block;height:auto;overflow:hidden}\n"],
		dependencies: [
			{
				kind: "directive",
				type: RouterLink,
				selector: "[routerLink]",
				inputs: [
					"target",
					"queryParams",
					"fragment",
					"queryParamsHandling",
					"state",
					"info",
					"relativeTo",
					"preserveFragment",
					"skipLocationChange",
					"replaceUrl",
					"browserUrl",
					"routerLink"
				]
			},
			{
				kind: "directive",
				type: RouterLinkActive,
				selector: "[routerLinkActive]",
				inputs: [
					"routerLinkActiveOptions",
					"ariaCurrentWhenActive",
					"routerLinkActive"
				],
				outputs: ["isActiveChange"],
				exportAs: ["routerLinkActive"]
			},
			{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			},
			{
				kind: "pipe",
				type: AsyncPipe,
				name: "async"
			}
		]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.1.6",
	ngImport: i0,
	type: SidebarLinkComponent,
	decorators: [{
		type: Component,
		args: [{
			imports: [
				RouterLink,
				RouterLinkActive,
				AsyncPipe,
				NgTemplateOutlet
			],
			selector: "cica-sidebar-link",
			template: "@let hasChildren = linkTemplates().length > 0;\n<div\n  class=\"nav-item\"\n  (click)=\"linkClicked()\"\n  [class.dropdown-container]=\"hasChildren\"\n>\n  <a\n    (click)=\"toggle.next({ event: 'click' })\"\n    class=\"nav-link\"\n    [class.dropdown-toggle]=\"hasChildren\"\n  >\n    <ng-content select=\".link-icon\" />\n    <span class=\"nav-label\"  [class.no-content]=\"!labelTemplate() && !label()\">\n      @if (labelTemplate(); as template) {\n    <ng-container\n      [ngTemplateOutlet]=\"template\"\n    />\n  } @else {\n    {{label()}}\n  }\n    </span>\n    @if (hasChildren) {\n      <span class=\"dropdown-icon\">\n\n<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24\" viewBox=\"0 0 24 24\" width=\"24\" fill=\"currentColor\">\n  <path d=\"M7.41 8.59 12 13.17l4.59-4.58L18 10l-6 6-6-6z\"/>\n</svg>\n\n      </span>\n    }\n  </a>\n  <div\n    class=\"dropdown-menu\"\n    [class.open]=\"isOpen$ | async\"\n  >\n    <div class=\"\">\n      @for (childLink of linkTemplates(); track childLink.url()) {\n        <div class=\"nav-item\">\n          <a\n            [routerLink]=\"childLink.url()\"\n            routerLinkActive=\"active\"\n            class=\"nav-link dropdown-link\"\n            >\n            <ng-template [ngTemplateOutlet]=\"childLink.templateRef\"></ng-template\n          ></a>\n        </div>\n      } @empty {\n        <div class=\"nav-item\">\n          <a\n            [routerLink]=\"url()\"\n            routerLinkActive=\"active\"\n            class=\"nav-link dropdown-link\"\n            [class.no-content]=\"!labelTemplate() && !label()\"\n            >@if (labelTemplate(); as template) {\n              <ng-container [ngTemplateOutlet]=\"template\" />\n            } @else {\n              {{ label() }}\n            }</a\n          >\n        </div>\n      }\n    </div>\n  </div>\n</div>\n",
			styles: [":host .nav-item{margin:0 .5rem}:host .nav-item:hover:has(.dropdown-menu a.active){border-left:none}:host .no-content{display:none}:host .nav-item .nav-link{color:var(--sidebar-light, #eef2ff);display:flex;gap:var(--navigation-link-space, .75rem);white-space:nowrap;border-radius:.5rem;padding:var(--navigation-link-space, .75rem);align-items:center;text-decoration:none;border:1px solid var(--sidebar-dark, #151a2d);transition:.4s ease;cursor:pointer}:host .nav-item:is(:hover,.open)>.nav-link:not(.dropdown-title){color:var(--sidebar-dark, #151a2d);background-color:var(--sidebar-light, #eef2ff)}:host .nav-item:has(.dropdown-menu):has(a.active) .nav-link:not(.dropdown-link),:host a.active{font-weight:700}:host .nav-link .nav-label{transition:opacity 3s ease;width:100%}:host .dropdown-icon{transition:transform .3s ease;transform:rotate(90deg)}:host .dropdown-toggle{cursor:pointer}:host-context(.sidebar-size.sm.sidebar-position-left) .dropdown-menu .nav-link,:host-context(.sidebar:not(:hover).sidebar-size-md.sidebar-position-left) .dropdown-menu .nav-link,:host-context(.sidebar.sidebar-position-top) .dropdown-menu .nav-link{min-width:160px}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-item .dropdown-menu{position:absolute;width:200px;height:auto!important;overflow:visible;opacity:1;z-index:1001;pointer-events:auto;background-color:var(--sidebar-dark, #151a2d);border-top-right-radius:.5rem;border-bottom-right-radius:.5rem}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) :host:hover>.dropdown-menu{display:block}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) :host:hover>.dropdown-menu:has(.no-content),:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-link.dropdown-link.no-content{display:none}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-item>.dropdown-menu{left:100%;top:0}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-link :where(.nav-label,.dropdown-icon),:host-context(.sidebar:not(:hover).sidebar-size-md.sidebar-position-left) .nav-link :where(.nav-label,.dropdown-icon){display:none!important}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-item .dropdown-menu,:host-context(.sidebar:not(:hover).sidebar-size-md.sidebar-position-left) .nav-item .dropdown-menu{display:none}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-item .nav-link,:host-context(.sidebar:not(:hover).sidebar-size-md.sidebar-position-left) .nav-item .nav-link{justify-content:center}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .dropdown-menu .nav-item .nav-link,:host-context(.sidebar:not(:hover).sidebar-size-md.sidebar-position-left) .dropdown-menu .nav-item .nav-link{justify-content:start}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .dropdown-menu .nav-item .dropdown-title,:host-context(.sidebar:not(:hover).sidebar-size-md.sidebar-position-left) .dropdown-menu .nav-item .dropdown-title{display:block}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-link .dropdown-icon,:host-context(.sidebar:not(:hover).sidebar-size-md.sidebar-position-left) .nav-link .dropdown-icon{transition:opacity .3s 0s easy}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .dropdown-menu:has(.dropdown-link),:host-context(.sidebar:not(:hover).sidebar-size-md.sidebar-position-left) .dropdown-menu:has(.dropdown-link){padding:var(--dropdown-menu-padding, .5rem)}:host-context(.sidebar.sidebar-size-sm.sidebar-position-left) .nav-item:hover>.dropdown-menu,:host-context(.sidebar:not(:hover).sidebar-size-md.sidebar-position-left) .nav-item:hover>.dropdown-menu{display:block;opacity:1;pointer-events:auto;transition:all .4s ease}.nav-item{position:relative}.dropdown-menu{height:0;overflow-y:hidden;padding-left:1rem;transition:height .4s ease}.dropdown-content{min-height:0;overflow:hidden}.dropdown-menu .nav-item .nav-link,.dropdown-menu .nav-item .nav-link .dropdown-title{color:var(--sidebar-light, #eef2ff);padding:.5rem .75rem}.dropdown-menu .nav-item .nav-link .dropdown-title{display:none}.dropdown-menu:has(.dropdown-link) .nav-item .dropdown-title{font-weight:500;padding:.5rem .75rem}:host-context(.sidebar.sidebar-position-top) .dropdown-menu{border-radius:.5rem;padding:.5rem 0}:host-context(.sidebar.sidebar-position-top) .nav-item.dropdown-container{padding:.25rem 0}:host-context(.sidebar.sidebar-position-top) .nav-item:has(.dropdown-menu):has(a.active):not(:hover) .nav-link:not(.dropdown-link){border-bottom-left-radius:0;border-bottom-right-radius:0;border-bottom:.125rem solid var(--sidebar-primary, rgb(86, 107, 223))}:host-context(.sidebar.sidebar-position-top) .nav-item.dropdown-container:hover>.dropdown-menu{display:block;height:auto;overflow:visible;opacity:1;pointer-events:auto}:host-context(.sidebar.sidebar-position-top) .dropdown-container .dropdown-menu.open{display:block;height:auto;overflow:visible}:host-context(.sidebar.sidebar-position-top) .dropdown-menu{position:absolute;bottom:0;transform:translateY(100%);left:0;z-index:1001;min-width:100%;padding-left:0;background-color:var(--sidebar-dark, #151a2d);display:none}:host-context(.sidebar.sidebar-position-top) .dropdown-icon{display:none}:host-context(.sidebar.sidebar-position-left) .nav-item:has(.dropdown-menu a.active){border-left:.25rem solid var(--sidebar-primary, rgb(86, 107, 223))}:host-context(.sidebar.sidebar-position-left) .nav-item:has(.dropdown-menu a.active){margin-left:.25rem}:host-context(.sidebar.sidebar-position-left) .dropdown-container .dropdown-menu.open{height:auto;overflow:visible}:host-context(.sidebar.sidebar-position-left) .dropdown-container.open .dropdown-icon{transform:rotate(180deg)}:host-context(.sidebar.sidebar-position-left) .nav-item:has(.dropdown-menu.open) .dropdown-icon{transform:rotate(0)}:host-context(.sidebar.sidebar-size-md.sidebar-position-left:hover) .dropdown-menu,:host-context(.sidebar.sidebar-size-lg.sidebar-position-left) .dropdown-menu{height:0;overflow:hidden;interpolate-size:allow-keywords;transition:height .4s ease}:host-context(.sidebar.sidebar-size-md.sidebar-position-left:hover) .nav-item .dropdown-menu a.nav-link.dropdown-link.active,:host-context(.sidebar.sidebar-size-lg.sidebar-position-left) .nav-item .dropdown-menu a.nav-link.dropdown-link.active{border-left:none}:host-context(.sidebar.sidebar-size-md.sidebar-position-left:hover) .nav-link :where(.nav-label,.dropdown-icon),:host-context(.sidebar.sidebar-size-lg.sidebar-position-left) .nav-link :where(.nav-label,.dropdown-icon){display:inline}:host-context(.sidebar.sidebar-size-md.sidebar-position-left:hover) .dropdown-menu,:host-context(.sidebar.sidebar-size-lg.sidebar-position-left) .dropdown-menu{position:static;opacity:1;pointer-events:auto;border-radius:0;background:transparent}:host-context(.sidebar.sidebar-size-md.sidebar-position-left:hover) .dropdown-container .dropdown-menu.open,:host-context(.sidebar.sidebar-size-lg.sidebar-position-left) .dropdown-container .dropdown-menu.open{display:block;height:auto;overflow:hidden}\n"]
		}]
	}],
	propDecorators: {
		url: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "url",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		linkClick: [{
			type: i0.Output,
			args: ["linkClick"]
		}],
		links$: [{
			type: i0.ViewChildren,
			args: [i0.forwardRef(() => RouterLinkActive), { isSignal: true }]
		}],
		labelTemplate: [{
			type: i0.ContentChild,
			args: ["labelTemplate", { isSignal: true }]
		}],
		linkTemplates: [{
			type: i0.ContentChildren,
			args: [i0.forwardRef(() => SidebarLinkTemplateDirective), { isSignal: true }]
		}]
	}
});
var SidebarWrapperComponent = class SidebarWrapperComponent {
	size = model("sm", ...ngDevMode ? [{ debugName: "size" }] : 	/* istanbul ignore next */ []);
	position = input("left", ...ngDevMode ? [{ debugName: "position" }] : 	/* istanbul ignore next */ []);
	showToggleButton = input(true, ...ngDevMode ? [{ debugName: "showToggleButton" }] : 	/* istanbul ignore next */ []);
	toggleMenu() {
		this.size.update((value) => value === "sm" ? "lg" : "sm");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: SidebarWrapperComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.1.6",
		type: SidebarWrapperComponent,
		isStandalone: true,
		selector: "cica-sidebar-wrapper",
		inputs: {
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			position: {
				classPropertyName: "position",
				publicName: "position",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showToggleButton: {
				classPropertyName: "showToggleButton",
				publicName: "showToggleButton",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { size: "sizeChange" },
		ngImport: i0,
		template: "<div\n  class=\"sidebar sidebar-size-{{ size() }} sidebar-position-{{ position() }}\"\n>\n  <div class=\"sidebar-header\">\n    <div class=\"logo-image-wrapper-lg\">\n      <ng-content select=\".logo-image-lg\" />\n    </div>\n    <div class=\"logo-image-wrapper-sm\">\n      <ng-content select=\".logo-image-sm\" />\n    </div>\n  </div>\n  <nav class=\"sidebar-nav\">\n  @if(showToggleButton()){\n    <button\n      (click)=\"toggleMenu()\"\n      class=\"sidebar-toggler\"\n      aria-label=\"Toggle Sidebar\"\n    >\n      <svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24\" viewBox=\"0 0 24 24\" width=\"24\" fill=\"currentColor\">\n        <path d=\"M7.41 8.59 12 13.17l4.59-4.58L18 10l-6 6-6-6z\"/>\n      </svg>\n    </button>\n  }\n  <ng-content select=\"cica-sidebar-link\" />\n  </nav>\n</div>\n",
		styles: [":host .sidebar{position:fixed;box-sizing:border-box;top:0;left:0;z-index:1000;height:100vh;width:var(--sidebar-width, 250px);display:flex;flex-direction:column;background-color:var(--sidebar-dark, #151a2d);transition:all .4s ease-in-out}:host .sidebar-header{padding:.9375rem;display:flex;box-sizing:border-box;flex-direction:row;align-items:center;justify-content:space-between;flex-shrink:0}:host .logo-image-wrapper-sm,:host .logo-image-wrapper-lg{height:100%;display:flex;align-items:center;justify-content:center}:host nav.sidebar-nav{position:relative;flex:1;min-height:0;display:flex;flex-direction:column;gap:.25rem;transition:.4s ease;overflow-y:auto;scrollbar-width:thin;scrollbar-color:transparent transparent;overflow:visible;padding:var(--sidebar-nav-list-vertical-padding, 20px) 0}:host .logo-image-wrapper-sm{display:none}:host .sidebar-toggler{position:absolute;display:flex;justify-content:center;align-items:center;right:0;top:0;transform:translate(50%,-50%);transition:left .3s ease;border:.125rem solid var(--sidebar-primary, rgb(86, 107, 223));border-radius:50%;z-index:2001}:host .sidebar-toggler svg{font-size:1.75rem;transition:.4s ease;transform:rotate(90deg)}:host .sidebar.sidebar-position-left.sidebar-size-sm .sidebar-header,:host .sidebar:not(:hover).sidebar-size-md.sidebar-position-left .sidebar-header{flex-direction:column;align-items:center;flex-shrink:0}:host .sidebar.sidebar-position-left.sidebar-size-sm .sidebar-toggler svg,:host .sidebar:not(:hover).sidebar-size-md.sidebar-position-left .sidebar-toggler svg{transform:rotate(270deg)}:host .sidebar.sidebar-size-md.sidebar-position-left .sidebar-toggler{display:none}:host .sidebar.sidebar-position-left.sidebar-size-sm,:host .sidebar:not(:hover).sidebar-size-md.sidebar-position-left{width:var(--sidebar-small-width, 70px)}:host .sidebar.sidebar-position-left.sidebar-size-sm .logo-image-wrapper-lg,:host .sidebar:not(:hover).sidebar-size-md.sidebar-position-left .logo-image-wrapper-lg,:host .sidebar.sidebar-position-top .logo-image-wrapper-lg{display:none}:host .sidebar.sidebar-position-left.sidebar-size-sm .logo-image-wrapper-sm,:host .sidebar:not(:hover).sidebar-size-md.sidebar-position-left .logo-image-wrapper-sm,:host .sidebar.sidebar-position-top .logo-image-wrapper-sm{display:flex}:host .sidebar.sidebar-size-sm.sidebar-position-left .nav-list.primary-nav,:host .sidebar.sidebar-position-top .nav-list.primary-nav{overflow:visible}:host .sidebar.sidebar-position-top{--sidebar-width: 100vw;height:var(--top-sidebar-height, 60px);padding:0 var(--sidebar-nav-list-vertical-padding, 20px);display:flex;flex-direction:row;align-items:center}:host .sidebar.sidebar-position-top .sidebar-toggler{display:none}:host .sidebar.sidebar-position-top nav.sidebar-nav{flex-direction:row;align-items:center;overflow:visible}\n"]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.1.6",
	ngImport: i0,
	type: SidebarWrapperComponent,
	decorators: [{
		type: Component,
		args: [{
			imports: [],
			selector: "cica-sidebar-wrapper",
			template: "<div\n  class=\"sidebar sidebar-size-{{ size() }} sidebar-position-{{ position() }}\"\n>\n  <div class=\"sidebar-header\">\n    <div class=\"logo-image-wrapper-lg\">\n      <ng-content select=\".logo-image-lg\" />\n    </div>\n    <div class=\"logo-image-wrapper-sm\">\n      <ng-content select=\".logo-image-sm\" />\n    </div>\n  </div>\n  <nav class=\"sidebar-nav\">\n  @if(showToggleButton()){\n    <button\n      (click)=\"toggleMenu()\"\n      class=\"sidebar-toggler\"\n      aria-label=\"Toggle Sidebar\"\n    >\n      <svg xmlns=\"http://www.w3.org/2000/svg\" height=\"24\" viewBox=\"0 0 24 24\" width=\"24\" fill=\"currentColor\">\n        <path d=\"M7.41 8.59 12 13.17l4.59-4.58L18 10l-6 6-6-6z\"/>\n      </svg>\n    </button>\n  }\n  <ng-content select=\"cica-sidebar-link\" />\n  </nav>\n</div>\n",
			styles: [":host .sidebar{position:fixed;box-sizing:border-box;top:0;left:0;z-index:1000;height:100vh;width:var(--sidebar-width, 250px);display:flex;flex-direction:column;background-color:var(--sidebar-dark, #151a2d);transition:all .4s ease-in-out}:host .sidebar-header{padding:.9375rem;display:flex;box-sizing:border-box;flex-direction:row;align-items:center;justify-content:space-between;flex-shrink:0}:host .logo-image-wrapper-sm,:host .logo-image-wrapper-lg{height:100%;display:flex;align-items:center;justify-content:center}:host nav.sidebar-nav{position:relative;flex:1;min-height:0;display:flex;flex-direction:column;gap:.25rem;transition:.4s ease;overflow-y:auto;scrollbar-width:thin;scrollbar-color:transparent transparent;overflow:visible;padding:var(--sidebar-nav-list-vertical-padding, 20px) 0}:host .logo-image-wrapper-sm{display:none}:host .sidebar-toggler{position:absolute;display:flex;justify-content:center;align-items:center;right:0;top:0;transform:translate(50%,-50%);transition:left .3s ease;border:.125rem solid var(--sidebar-primary, rgb(86, 107, 223));border-radius:50%;z-index:2001}:host .sidebar-toggler svg{font-size:1.75rem;transition:.4s ease;transform:rotate(90deg)}:host .sidebar.sidebar-position-left.sidebar-size-sm .sidebar-header,:host .sidebar:not(:hover).sidebar-size-md.sidebar-position-left .sidebar-header{flex-direction:column;align-items:center;flex-shrink:0}:host .sidebar.sidebar-position-left.sidebar-size-sm .sidebar-toggler svg,:host .sidebar:not(:hover).sidebar-size-md.sidebar-position-left .sidebar-toggler svg{transform:rotate(270deg)}:host .sidebar.sidebar-size-md.sidebar-position-left .sidebar-toggler{display:none}:host .sidebar.sidebar-position-left.sidebar-size-sm,:host .sidebar:not(:hover).sidebar-size-md.sidebar-position-left{width:var(--sidebar-small-width, 70px)}:host .sidebar.sidebar-position-left.sidebar-size-sm .logo-image-wrapper-lg,:host .sidebar:not(:hover).sidebar-size-md.sidebar-position-left .logo-image-wrapper-lg,:host .sidebar.sidebar-position-top .logo-image-wrapper-lg{display:none}:host .sidebar.sidebar-position-left.sidebar-size-sm .logo-image-wrapper-sm,:host .sidebar:not(:hover).sidebar-size-md.sidebar-position-left .logo-image-wrapper-sm,:host .sidebar.sidebar-position-top .logo-image-wrapper-sm{display:flex}:host .sidebar.sidebar-size-sm.sidebar-position-left .nav-list.primary-nav,:host .sidebar.sidebar-position-top .nav-list.primary-nav{overflow:visible}:host .sidebar.sidebar-position-top{--sidebar-width: 100vw;height:var(--top-sidebar-height, 60px);padding:0 var(--sidebar-nav-list-vertical-padding, 20px);display:flex;flex-direction:row;align-items:center}:host .sidebar.sidebar-position-top .sidebar-toggler{display:none}:host .sidebar.sidebar-position-top nav.sidebar-nav{flex-direction:row;align-items:center;overflow:visible}\n"]
		}]
	}],
	propDecorators: {
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["sizeChange"]
		}],
		position: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "position",
				required: false
			}]
		}],
		showToggleButton: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showToggleButton",
				required: false
			}]
		}]
	}
});
var InputComponent = class InputComponent {
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : 	/* istanbul ignore next */ []);
	placeholder = input(...ngDevMode ? [void 0, { debugName: "placeholder" }] : 	/* istanbul ignore next */ []);
	errorMessage = input(...ngDevMode ? [void 0, { debugName: "errorMessage" }] : 	/* istanbul ignore next */ []);
	labelPosition = input("top", ...ngDevMode ? [{ debugName: "labelPosition" }] : 	/* istanbul ignore next */ []);
	value = model(null, ...ngDevMode ? [{ debugName: "value" }] : 	/* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : 	/* istanbul ignore next */ []);
	hidden = input(false, ...ngDevMode ? [{ debugName: "hidden" }] : 	/* istanbul ignore next */ []);
	invalid = input(false, ...ngDevMode ? [{ debugName: "invalid" }] : 	/* istanbul ignore next */ []);
	touched = input(false, ...ngDevMode ? [{ debugName: "touched" }] : 	/* istanbul ignore next */ []);
	showClearIcon = input(false, ...ngDevMode ? [{ debugName: "showClearIcon" }] : 	/* istanbul ignore next */ []);
	showTogglePassword = input(true, ...ngDevMode ? [{ debugName: "showTogglePassword" }] : 	/* istanbul ignore next */ []);
	required = input(false, ...ngDevMode ? [{ debugName: "required" }] : 	/* istanbul ignore next */ []);
	inputType = input("text", ...ngDevMode ? [{ debugName: "inputType" }] : 	/* istanbul ignore next */ []);
	labelClick(target) {
		if (target) target.parentElement?.querySelector("input")?.focus();
	}
	clear() {
		this.value.set("");
	}
	togglePassword(target) {
		if (!target) return;
		const element = target;
		const input = element.closest(".input-wrapper")?.querySelector("input");
		input.type = input.type === "password" ? "text" : "password";
		element.querySelectorAll("svg").forEach((e) => e.classList.toggle("d-none"));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: InputComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.1.6",
		type: InputComponent,
		isStandalone: true,
		selector: "cica-input",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			errorMessage: {
				classPropertyName: "errorMessage",
				publicName: "errorMessage",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			labelPosition: {
				classPropertyName: "labelPosition",
				publicName: "labelPosition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hidden: {
				classPropertyName: "hidden",
				publicName: "hidden",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			invalid: {
				classPropertyName: "invalid",
				publicName: "invalid",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			touched: {
				classPropertyName: "touched",
				publicName: "touched",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showClearIcon: {
				classPropertyName: "showClearIcon",
				publicName: "showClearIcon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showTogglePassword: {
				classPropertyName: "showTogglePassword",
				publicName: "showTogglePassword",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			inputType: {
				classPropertyName: "inputType",
				publicName: "inputType",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { value: "valueChange" },
		host: { properties: { "class.hidden": "hidden()" } },
		ngImport: i0,
		template: "\n<div class=\"form-group\" [class.ç]=\"disabled()\">\n      @if(label()){\n      <label (click)=\"labelClick($event.target)\">{{label() }} \n        @if(required()){\n          <span class=\"red-label\">*</span>\n        }\n      </label>\n      }\n\n      <div class=\"input-wrapper\">\n        <input\n          [class.invalid]=\"invalid() && touched()\"\n          [type]=\"inputType()\"\n          [value]=\"value()\"\n          (input)=\"value.set($event.target.value)\"\n          placeholder=\"{{ placeholder() ? placeholder() : 'Enter ' +label()}}\"\n        />\n        <div class=\"left-icon-wrapper\">\n            <ng-content select=\".left-icon\"></ng-content>\n        </div>\n         <div class=\"right-icon-wrapper\">\n            <ng-content select=\".right-icon\"></ng-content>\n            @if(inputType() === 'password' && showTogglePassword()){\n            <div class=\"password-input-container\"  (click)=\"togglePassword($event.currentTarget)\">\n              <svg\n          class=\"eye-icon\"\n          xmlns=\"http://www.w3.org/2000/svg\"\n          width=\"20\"\n          height=\"20\"\n          viewBox=\"0 0 24 24\"\n          fill=\"none\"\n          stroke=\"currentColor\"\n          stroke-width=\"2\"\n          stroke-linecap=\"round\"\n          stroke-linejoin=\"round\"\n        >\n          <path d=\"M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7Z\"/>\n          <circle cx=\"12\" cy=\"12\" r=\"3\"/>\n        </svg>\n\n        <!-- Eye-off icon -->\n        <svg \n          class=\"eye-off-icon d-none\"\n          xmlns=\"http://www.w3.org/2000/svg\"\n          width=\"20\"\n          height=\"20\"\n          viewBox=\"0 0 24 24\"\n          fill=\"none\"\n          stroke=\"currentColor\"\n          stroke-width=\"2\"\n          stroke-linecap=\"round\"\n          stroke-linejoin=\"round\"\n          hidden\n        >\n          <path d=\"m3 3 18 18\"/>\n          <path d=\"M10.6 10.6a2 2 0 0 0 2.8 2.8\"/>\n          <path d=\"M9.9 5.2A10.8 10.8 0 0 1 12 5c6.4 0 10 7 10 7a14.5 14.5 0 0 1-3.2 4.1\"/>\n          <path d=\"M6.2 6.2C3.5 8 2 12 2 12s3.6 7 10 7a10 10 0 0 0 4-.8\"/>\n        </svg>\n            </div>\n            \n               \n            }\n            @if(value() && showClearIcon()){\n               <span class=\"close-icon-wrapper\" (click)=\"clear()\"> <svg\n      xmlns=\"http://www.w3.org/2000/svg\"\n      width=\"18\"\n      height=\"18\"\n      viewBox=\"0 0 24 24\"\n      fill=\"none\"\n      stroke=\"currentColor\"\n      stroke-width=\"2\"\n      stroke-linecap=\"round\"\n      stroke-linejoin=\"round\"\n    >\n      <path d=\"M18 6 6 18\" />\n      <path d=\"m6 6 12 12\" />\n    </svg> </span>\n            }\n        </div>\n\n        @if(invalid() && touched()){\n            <span  class=\"error-message\">\n            {{errorMessage()}}\n            </span>\n        }\n      </div>\n</div>\n",
		styles: [":host .form-group{display:flex;align-items:flex-start;gap:12px;width:100%}:host .form-group.input-disabled inpup{pointer-events:none;cursor:not-allowed;background-color:#868481}:host .red-label,:host .error-message{color:#dc3545}:host .password-input-container{cursor:pointer;padding:4px}:host .d-none{display:none}:host .form-group label{width:100px;flex-shrink:0;padding-top:10px}:host .input-wrapper{display:flex;position:relative;flex-direction:column;flex:1;width:100%;min-width:0;gap:4px}:host .input-wrapper .left-icon-wrapper,:host .input-wrapper .right-icon-wrapper{position:absolute;top:50%;transform:translateY(-50%);color:#6b7280;max-width:22px;cursor:pointer;z-index:100}:host .input-wrapper .close-icon-wrapper{cursor:pointer;padding:4px}:host .input-wrapper .left-icon-wrapper{left:14px}:host .input-wrapper .right-icon-wrapper{right:14px;display:flex;gap:4px}:host .input-wrapper input{padding-top:var(--vertical-input-pedding, 10px);padding-bottom:var(--vertical-input-pedding, 10px);padding-right:var(--input-right-pedding, 10px);padding-left:var(--input-left-pedding, 10px);border:1px solid #ccc;border-radius:4px;font-size:14px}:host .input-wrapper input.invalid{border-color:#dc3545}:host .error-message{font-size:12px}\n"]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.1.6",
	ngImport: i0,
	type: InputComponent,
	decorators: [{
		type: Component,
		args: [{
			imports: [],
			selector: "cica-input",
			host: { "[class.hidden]": "hidden()" },
			template: "\n<div class=\"form-group\" [class.ç]=\"disabled()\">\n      @if(label()){\n      <label (click)=\"labelClick($event.target)\">{{label() }} \n        @if(required()){\n          <span class=\"red-label\">*</span>\n        }\n      </label>\n      }\n\n      <div class=\"input-wrapper\">\n        <input\n          [class.invalid]=\"invalid() && touched()\"\n          [type]=\"inputType()\"\n          [value]=\"value()\"\n          (input)=\"value.set($event.target.value)\"\n          placeholder=\"{{ placeholder() ? placeholder() : 'Enter ' +label()}}\"\n        />\n        <div class=\"left-icon-wrapper\">\n            <ng-content select=\".left-icon\"></ng-content>\n        </div>\n         <div class=\"right-icon-wrapper\">\n            <ng-content select=\".right-icon\"></ng-content>\n            @if(inputType() === 'password' && showTogglePassword()){\n            <div class=\"password-input-container\"  (click)=\"togglePassword($event.currentTarget)\">\n              <svg\n          class=\"eye-icon\"\n          xmlns=\"http://www.w3.org/2000/svg\"\n          width=\"20\"\n          height=\"20\"\n          viewBox=\"0 0 24 24\"\n          fill=\"none\"\n          stroke=\"currentColor\"\n          stroke-width=\"2\"\n          stroke-linecap=\"round\"\n          stroke-linejoin=\"round\"\n        >\n          <path d=\"M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7Z\"/>\n          <circle cx=\"12\" cy=\"12\" r=\"3\"/>\n        </svg>\n\n        <!-- Eye-off icon -->\n        <svg \n          class=\"eye-off-icon d-none\"\n          xmlns=\"http://www.w3.org/2000/svg\"\n          width=\"20\"\n          height=\"20\"\n          viewBox=\"0 0 24 24\"\n          fill=\"none\"\n          stroke=\"currentColor\"\n          stroke-width=\"2\"\n          stroke-linecap=\"round\"\n          stroke-linejoin=\"round\"\n          hidden\n        >\n          <path d=\"m3 3 18 18\"/>\n          <path d=\"M10.6 10.6a2 2 0 0 0 2.8 2.8\"/>\n          <path d=\"M9.9 5.2A10.8 10.8 0 0 1 12 5c6.4 0 10 7 10 7a14.5 14.5 0 0 1-3.2 4.1\"/>\n          <path d=\"M6.2 6.2C3.5 8 2 12 2 12s3.6 7 10 7a10 10 0 0 0 4-.8\"/>\n        </svg>\n            </div>\n            \n               \n            }\n            @if(value() && showClearIcon()){\n               <span class=\"close-icon-wrapper\" (click)=\"clear()\"> <svg\n      xmlns=\"http://www.w3.org/2000/svg\"\n      width=\"18\"\n      height=\"18\"\n      viewBox=\"0 0 24 24\"\n      fill=\"none\"\n      stroke=\"currentColor\"\n      stroke-width=\"2\"\n      stroke-linecap=\"round\"\n      stroke-linejoin=\"round\"\n    >\n      <path d=\"M18 6 6 18\" />\n      <path d=\"m6 6 12 12\" />\n    </svg> </span>\n            }\n        </div>\n\n        @if(invalid() && touched()){\n            <span  class=\"error-message\">\n            {{errorMessage()}}\n            </span>\n        }\n      </div>\n</div>\n",
			styles: [":host .form-group{display:flex;align-items:flex-start;gap:12px;width:100%}:host .form-group.input-disabled inpup{pointer-events:none;cursor:not-allowed;background-color:#868481}:host .red-label,:host .error-message{color:#dc3545}:host .password-input-container{cursor:pointer;padding:4px}:host .d-none{display:none}:host .form-group label{width:100px;flex-shrink:0;padding-top:10px}:host .input-wrapper{display:flex;position:relative;flex-direction:column;flex:1;width:100%;min-width:0;gap:4px}:host .input-wrapper .left-icon-wrapper,:host .input-wrapper .right-icon-wrapper{position:absolute;top:50%;transform:translateY(-50%);color:#6b7280;max-width:22px;cursor:pointer;z-index:100}:host .input-wrapper .close-icon-wrapper{cursor:pointer;padding:4px}:host .input-wrapper .left-icon-wrapper{left:14px}:host .input-wrapper .right-icon-wrapper{right:14px;display:flex;gap:4px}:host .input-wrapper input{padding-top:var(--vertical-input-pedding, 10px);padding-bottom:var(--vertical-input-pedding, 10px);padding-right:var(--input-right-pedding, 10px);padding-left:var(--input-left-pedding, 10px);border:1px solid #ccc;border-radius:4px;font-size:14px}:host .input-wrapper input.invalid{border-color:#dc3545}:host .error-message{font-size:12px}\n"]
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		errorMessage: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "errorMessage",
				required: false
			}]
		}],
		labelPosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "labelPosition",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["valueChange"]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		hidden: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hidden",
				required: false
			}]
		}],
		invalid: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "invalid",
				required: false
			}]
		}],
		touched: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "touched",
				required: false
			}]
		}],
		showClearIcon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showClearIcon",
				required: false
			}]
		}],
		showTogglePassword: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showTogglePassword",
				required: false
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		inputType: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "inputType",
				required: false
			}]
		}]
	}
});
var ModalComponent = class ModalComponent {
	cancelLabel = input(...ngDevMode ? [void 0, { debugName: "cancelLabel" }] : 	/* istanbul ignore next */ []);
	confirmLabel = input(...ngDevMode ? [void 0, { debugName: "confirmLabel" }] : 	/* istanbul ignore next */ []);
	fullHeight = input(false, ...ngDevMode ? [{ debugName: "fullHeight" }] : 	/* istanbul ignore next */ []);
	modalPosition = input("center", ...ngDevMode ? [{ debugName: "modalPosition" }] : 	/* istanbul ignore next */ []);
	showWarningIcon = input(true, ...ngDevMode ? [{ debugName: "showWarningIcon" }] : 	/* istanbul ignore next */ []);
	headerText = input(...ngDevMode ? [void 0, { debugName: "headerText" }] : 	/* istanbul ignore next */ []);
	submitFormType = input(null, ...ngDevMode ? [{ debugName: "submitFormType" }] : 	/* istanbul ignore next */ []);
	initValue = input(...ngDevMode ? [void 0, { debugName: "initValue" }] : 	/* istanbul ignore next */ []);
	onConfirm = output();
	onCancel = output();
	onSuccess = output();
	formHost;
	submitFormRef;
	injector = inject(Injector);
	environmentInjector = inject(EnvironmentInjector);
	ngAfterViewInit() {
		const formType = this.submitFormType();
		if (!formType) return;
		const initialValue = this.initValue();
		const clonedValue = initialValue == null ? initialValue : structuredClone(initialValue);
		this.submitFormRef = this.formHost.createComponent(formType, {
			injector: this.injector,
			environmentInjector: this.environmentInjector,
			bindings: [inputBinding("initValue", () => clonedValue)]
		});
		this.submitFormRef.instance.onClose.subscribe((result) => {
			if (result) this.onSuccess.emit(result);
		});
	}
	confirm() {
		if (this.submitFormRef) submit(this.submitFormRef.instance.form);
		else this.onConfirm.emit();
	}
	cancel() {
		this.onCancel.emit();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: ModalComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.1.6",
		type: ModalComponent,
		isStandalone: true,
		selector: "cica-modal",
		inputs: {
			cancelLabel: {
				classPropertyName: "cancelLabel",
				publicName: "cancelLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			confirmLabel: {
				classPropertyName: "confirmLabel",
				publicName: "confirmLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fullHeight: {
				classPropertyName: "fullHeight",
				publicName: "fullHeight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			modalPosition: {
				classPropertyName: "modalPosition",
				publicName: "modalPosition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showWarningIcon: {
				classPropertyName: "showWarningIcon",
				publicName: "showWarningIcon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			headerText: {
				classPropertyName: "headerText",
				publicName: "headerText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			submitFormType: {
				classPropertyName: "submitFormType",
				publicName: "submitFormType",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			initValue: {
				classPropertyName: "initValue",
				publicName: "initValue",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			onConfirm: "onConfirm",
			onCancel: "onCancel",
			onSuccess: "onSuccess"
		},
		viewQueries: [{
			propertyName: "formHost",
			first: true,
			predicate: ["formHost"],
			descendants: true,
			read: ViewContainerRef
		}],
		ngImport: i0,
		template: "\n<div class=\"modal-overlay modal-position-{{modalPosition()}}\">\n  <div class=\"confirm-modal\"  [class.full-h]=\"fullHeight()\">\n    <div class=\"modal-header\">\n      @if(showWarningIcon()){\n      <div class=\"modal-icon\">\n        <svg viewBox=\"0 0 24 24\" width=\"24\" height=\"24\"\n             fill=\"none\" stroke=\"currentColor\"\n             stroke-width=\"2\" stroke-linecap=\"round\">\n          <path d=\"M12 9v4m0 4h.01\" />\n          <path d=\"M10.3 3.9 1.8 18.5a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z\" />\n        </svg>\n      </div>\n    }\n      <h3><span >{{headerText() ?? 'Are you shure?'}}</span>\n        <span (click)=\"cancel()\" class=\"close-icon-wrapper\"><svg\n      xmlns=\"http://www.w3.org/2000/svg\"\n      width=\"18\"\n      height=\"18\"\n      viewBox=\"0 0 24 24\"\n      fill=\"none\"\n      stroke=\"currentColor\"\n      stroke-width=\"2\"\n      stroke-linecap=\"round\"\n      stroke-linejoin=\"round\"\n    >\n      <path d=\"M18 6 6 18\" />\n      <path d=\"m6 6 12 12\" />\n    </svg>\n        </span>\n      </h3>\n    </div>\n  <ng-content />\n  <ng-container #formHost></ng-container>\n    <div class=\"modal-actions\">\n      <button class=\"btn btn-secondary\" (click)=\"cancel()\">{{ cancelLabel() ?? 'Cancel'}}</button>\n      <button class=\"btn btn-confirm\" (click)=\"confirm()\">{{ confirmLabel() ?? 'Confirm'}}</button>\n    </div>\n  </div>\n</div>\n\n",
		styles: [".modal-overlay{position:fixed;inset:0;z-index:20001;display:flex;align-items:center;background:#00000073}.modal-overlay.modal-position-left{justify-content:flex-start}.modal-overlay.modal-position-right{justify-content:flex-end}.modal-overlay.modal-position-center{justify-content:center}.confirm-modal{display:flex;flex-direction:column;gap:1rem;width:100%;max-width:420px;padding:24px;background:#fff;border-radius:12px;box-shadow:0 10px 35px #00000026}.confirm-modal.full-h{height:calc(100vh - 48px)}.modal-header{display:flex;align-items:center;gap:12px}.modal-header h3{margin:0;font-size:18px;font-weight:600;color:#222;display:flex;justify-content:space-between;align-items:center;width:100%}.modal-header h3>.close-icon-wrapper{padding:4px;cursor:pointer}.modal-icon{display:flex;align-items:center;justify-content:center;width:40px;height:40px;flex-shrink:0;color:#d97706;background:#fef3c7;border-radius:50%}.modal-description{margin:16px 0 24px;font-size:14px;line-height:1.5;color:#666}.modal-actions{display:flex;justify-content:flex-end;gap:10px}.btn{padding:9px 16px;border:1px solid transparent;border-radius:6px;font-size:14px;font-weight:500;cursor:pointer;transition:background .2s ease}.btn-secondary{color:#333;background:#fff;border-color:#ddd}.btn-secondary:hover{background:#f5f5f5}.btn-danger{color:#fff;background:#dc2626}.btn-danger:hover{background:#b91c1c}.btn-confirm{color:#fff;background:#263edc}.btn-confirm:hover{background:#1c5db9}@media(max-width:480px){.confirm-modal{max-width:none;padding:20px}}\n"]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.1.6",
	ngImport: i0,
	type: ModalComponent,
	decorators: [{
		type: Component,
		args: [{
			imports: [],
			selector: "cica-modal",
			template: "\n<div class=\"modal-overlay modal-position-{{modalPosition()}}\">\n  <div class=\"confirm-modal\"  [class.full-h]=\"fullHeight()\">\n    <div class=\"modal-header\">\n      @if(showWarningIcon()){\n      <div class=\"modal-icon\">\n        <svg viewBox=\"0 0 24 24\" width=\"24\" height=\"24\"\n             fill=\"none\" stroke=\"currentColor\"\n             stroke-width=\"2\" stroke-linecap=\"round\">\n          <path d=\"M12 9v4m0 4h.01\" />\n          <path d=\"M10.3 3.9 1.8 18.5a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z\" />\n        </svg>\n      </div>\n    }\n      <h3><span >{{headerText() ?? 'Are you shure?'}}</span>\n        <span (click)=\"cancel()\" class=\"close-icon-wrapper\"><svg\n      xmlns=\"http://www.w3.org/2000/svg\"\n      width=\"18\"\n      height=\"18\"\n      viewBox=\"0 0 24 24\"\n      fill=\"none\"\n      stroke=\"currentColor\"\n      stroke-width=\"2\"\n      stroke-linecap=\"round\"\n      stroke-linejoin=\"round\"\n    >\n      <path d=\"M18 6 6 18\" />\n      <path d=\"m6 6 12 12\" />\n    </svg>\n        </span>\n      </h3>\n    </div>\n  <ng-content />\n  <ng-container #formHost></ng-container>\n    <div class=\"modal-actions\">\n      <button class=\"btn btn-secondary\" (click)=\"cancel()\">{{ cancelLabel() ?? 'Cancel'}}</button>\n      <button class=\"btn btn-confirm\" (click)=\"confirm()\">{{ confirmLabel() ?? 'Confirm'}}</button>\n    </div>\n  </div>\n</div>\n\n",
			styles: [".modal-overlay{position:fixed;inset:0;z-index:20001;display:flex;align-items:center;background:#00000073}.modal-overlay.modal-position-left{justify-content:flex-start}.modal-overlay.modal-position-right{justify-content:flex-end}.modal-overlay.modal-position-center{justify-content:center}.confirm-modal{display:flex;flex-direction:column;gap:1rem;width:100%;max-width:420px;padding:24px;background:#fff;border-radius:12px;box-shadow:0 10px 35px #00000026}.confirm-modal.full-h{height:calc(100vh - 48px)}.modal-header{display:flex;align-items:center;gap:12px}.modal-header h3{margin:0;font-size:18px;font-weight:600;color:#222;display:flex;justify-content:space-between;align-items:center;width:100%}.modal-header h3>.close-icon-wrapper{padding:4px;cursor:pointer}.modal-icon{display:flex;align-items:center;justify-content:center;width:40px;height:40px;flex-shrink:0;color:#d97706;background:#fef3c7;border-radius:50%}.modal-description{margin:16px 0 24px;font-size:14px;line-height:1.5;color:#666}.modal-actions{display:flex;justify-content:flex-end;gap:10px}.btn{padding:9px 16px;border:1px solid transparent;border-radius:6px;font-size:14px;font-weight:500;cursor:pointer;transition:background .2s ease}.btn-secondary{color:#333;background:#fff;border-color:#ddd}.btn-secondary:hover{background:#f5f5f5}.btn-danger{color:#fff;background:#dc2626}.btn-danger:hover{background:#b91c1c}.btn-confirm{color:#fff;background:#263edc}.btn-confirm:hover{background:#1c5db9}@media(max-width:480px){.confirm-modal{max-width:none;padding:20px}}\n"]
		}]
	}],
	propDecorators: {
		cancelLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "cancelLabel",
				required: false
			}]
		}],
		confirmLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "confirmLabel",
				required: false
			}]
		}],
		fullHeight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fullHeight",
				required: false
			}]
		}],
		modalPosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "modalPosition",
				required: false
			}]
		}],
		showWarningIcon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showWarningIcon",
				required: false
			}]
		}],
		headerText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "headerText",
				required: false
			}]
		}],
		submitFormType: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "submitFormType",
				required: false
			}]
		}],
		initValue: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "initValue",
				required: false
			}]
		}],
		onConfirm: [{
			type: i0.Output,
			args: ["onConfirm"]
		}],
		onCancel: [{
			type: i0.Output,
			args: ["onCancel"]
		}],
		onSuccess: [{
			type: i0.Output,
			args: ["onSuccess"]
		}],
		formHost: [{
			type: ViewChild,
			args: ["formHost", { read: ViewContainerRef }]
		}]
	}
});
var CardComponent = class CardComponent {
	cardTitle = input.required(...ngDevMode ? [{ debugName: "cardTitle" }] : 	/* istanbul ignore next */ []);
	cardSubtitle = input("", ...ngDevMode ? [{ debugName: "cardSubtitle" }] : 	/* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: CardComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.1.6",
		type: CardComponent,
		isStandalone: true,
		selector: "cica-card",
		inputs: {
			cardTitle: {
				classPropertyName: "cardTitle",
				publicName: "cardTitle",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			cardSubtitle: {
				classPropertyName: "cardSubtitle",
				publicName: "cardSubtitle",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: "<div class=\"card\">\n  <div class=\"card-header\">\n    <div class=\"card-title\">\n      <h3>{{ cardTitle() }}</h3>\n      <ng-content select=\"[slot=cardTitle]\" />\n    </div>\n    @if (cardSubtitle()) {\n      <div class=\"card-subtitle\">\n        <p>{{ cardSubtitle() }}</p>\n        <ng-content select=\"[slot=cardSubtitle]\" />\n      </div>\n    }\n  </div>\n\n  <div class=\"card-content\">\n    <ng-content select=\"[slot=conrent]\" />\n  </div>\n\n  <!-- <div class=\"card-footer\">\n    <ng-content select=\"[slot=footer]\" />\n  </div> -->\n</div>\n",
		styles: [".card{position:relative;width:100%;padding:16px;background:#fff;border:1px solid #e5e7eb;border-radius:10px;box-sizing:border-box}.card .card-header{display:flex;flex-direction:column;align-items:flex-start;justify-content:space-between;gap:12px}.card .card-title,.card .card-subtitle{width:100%;display:flex;flex-direction:row;justify-content:space-between;align-items:center}.card .card-title{min-width:0}.card .card-title h3{margin:0;font-size:16px;font-weight:600;color:#1f2937}.card .card-subtitle p{margin:5px 0 0;font-size:13px;color:#6b7280}.card .card-content{margin-top:16px}.card .card-footer{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:16px;padding-top:12px;border-top:1px solid #e5e7eb}\n"]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.1.6",
	ngImport: i0,
	type: CardComponent,
	decorators: [{
		type: Component,
		args: [{
			imports: [],
			selector: "cica-card",
			template: "<div class=\"card\">\n  <div class=\"card-header\">\n    <div class=\"card-title\">\n      <h3>{{ cardTitle() }}</h3>\n      <ng-content select=\"[slot=cardTitle]\" />\n    </div>\n    @if (cardSubtitle()) {\n      <div class=\"card-subtitle\">\n        <p>{{ cardSubtitle() }}</p>\n        <ng-content select=\"[slot=cardSubtitle]\" />\n      </div>\n    }\n  </div>\n\n  <div class=\"card-content\">\n    <ng-content select=\"[slot=conrent]\" />\n  </div>\n\n  <!-- <div class=\"card-footer\">\n    <ng-content select=\"[slot=footer]\" />\n  </div> -->\n</div>\n",
			styles: [".card{position:relative;width:100%;padding:16px;background:#fff;border:1px solid #e5e7eb;border-radius:10px;box-sizing:border-box}.card .card-header{display:flex;flex-direction:column;align-items:flex-start;justify-content:space-between;gap:12px}.card .card-title,.card .card-subtitle{width:100%;display:flex;flex-direction:row;justify-content:space-between;align-items:center}.card .card-title{min-width:0}.card .card-title h3{margin:0;font-size:16px;font-weight:600;color:#1f2937}.card .card-subtitle p{margin:5px 0 0;font-size:13px;color:#6b7280}.card .card-content{margin-top:16px}.card .card-footer{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:16px;padding-top:12px;border-top:1px solid #e5e7eb}\n"]
		}]
	}],
	propDecorators: {
		cardTitle: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "cardTitle",
				required: true
			}]
		}],
		cardSubtitle: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "cardSubtitle",
				required: false
			}]
		}]
	}
});
var MenuButtonComponent = class MenuButtonComponent {
	isOpen = input(false, ...ngDevMode ? [{ debugName: "isOpen" }] : 	/* istanbul ignore next */ []);
	isHidden = input(false, ...ngDevMode ? [{ debugName: "isHidden" }] : 	/* istanbul ignore next */ []);
	dropdownTrigger = output();
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: MenuButtonComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.1.6",
		type: MenuButtonComponent,
		isStandalone: true,
		selector: "cica-menu-button",
		inputs: {
			isOpen: {
				classPropertyName: "isOpen",
				publicName: "isOpen",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isHidden: {
				classPropertyName: "isHidden",
				publicName: "isHidden",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { dropdownTrigger: "dropdownTrigger" },
		ngImport: i0,
		template: "<div class=\"dropdown\">\n  <button\n    type=\"button\"\n    class=\"dropdown-trigger\"\n    (click)=\"dropdownTrigger.emit()\"\n    aria-label=\"Open menu\"\n    [attr.aria-expanded]=\"isOpen()\"\n  >\n    <svg\n      width=\"20\"\n      height=\"20\"\n      viewBox=\"0 0 24 24\"\n      fill=\"currentColor\"\n      xmlns=\"http://www.w3.org/2000/svg\"\n    >\n      <circle\n        cx=\"12\"\n        cy=\"5\"\n        r=\"2\"\n      />\n      <circle\n        cx=\"12\"\n        cy=\"12\"\n        r=\"2\"\n      />\n      <circle\n        cx=\"12\"\n        cy=\"19\"\n        r=\"2\"\n      />\n    </svg>\n  </button>\n\n  @if (isOpen()) {\n    <div class=\"dropdown-menu\" [class.hidden]=\"isHidden()\">\n      <ng-content />\n    </div>\n  }\n</div>\n",
		styles: [".dropdown{position:relative;display:inline-block}.dropdown-trigger{display:flex;align-items:center;justify-content:center;border-radius:50%;width:36px;height:36px;padding:0;border:none;background:transparent;color:#555;cursor:pointer}.dropdown-trigger:hover{background:#f0f0f0}.dropdown-menu{position:absolute;top:calc(100% + 4px);right:0;min-width:160px;padding:5px;background:#fff;border:1px solid #e5e5e5;border-radius:8px;box-shadow:0 4px 12px #0000001f;z-index:100000}.dropdown-menu.hidden{display:none}.dropdown-item{display:block;width:100%;padding:9px 12px;border:none;border-radius:5px;background:transparent;text-align:left;font-size:14px;cursor:pointer}.dropdown-item:hover{background:#f5f5f5}.dropdown-item.danger{color:#dc2626}\n"]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.1.6",
	ngImport: i0,
	type: MenuButtonComponent,
	decorators: [{
		type: Component,
		args: [{
			imports: [],
			selector: "cica-menu-button",
			template: "<div class=\"dropdown\">\n  <button\n    type=\"button\"\n    class=\"dropdown-trigger\"\n    (click)=\"dropdownTrigger.emit()\"\n    aria-label=\"Open menu\"\n    [attr.aria-expanded]=\"isOpen()\"\n  >\n    <svg\n      width=\"20\"\n      height=\"20\"\n      viewBox=\"0 0 24 24\"\n      fill=\"currentColor\"\n      xmlns=\"http://www.w3.org/2000/svg\"\n    >\n      <circle\n        cx=\"12\"\n        cy=\"5\"\n        r=\"2\"\n      />\n      <circle\n        cx=\"12\"\n        cy=\"12\"\n        r=\"2\"\n      />\n      <circle\n        cx=\"12\"\n        cy=\"19\"\n        r=\"2\"\n      />\n    </svg>\n  </button>\n\n  @if (isOpen()) {\n    <div class=\"dropdown-menu\" [class.hidden]=\"isHidden()\">\n      <ng-content />\n    </div>\n  }\n</div>\n",
			styles: [".dropdown{position:relative;display:inline-block}.dropdown-trigger{display:flex;align-items:center;justify-content:center;border-radius:50%;width:36px;height:36px;padding:0;border:none;background:transparent;color:#555;cursor:pointer}.dropdown-trigger:hover{background:#f0f0f0}.dropdown-menu{position:absolute;top:calc(100% + 4px);right:0;min-width:160px;padding:5px;background:#fff;border:1px solid #e5e5e5;border-radius:8px;box-shadow:0 4px 12px #0000001f;z-index:100000}.dropdown-menu.hidden{display:none}.dropdown-item{display:block;width:100%;padding:9px 12px;border:none;border-radius:5px;background:transparent;text-align:left;font-size:14px;cursor:pointer}.dropdown-item:hover{background:#f5f5f5}.dropdown-item.danger{color:#dc2626}\n"]
		}]
	}],
	propDecorators: {
		isOpen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isOpen",
				required: false
			}]
		}],
		isHidden: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isHidden",
				required: false
			}]
		}],
		dropdownTrigger: [{
			type: i0.Output,
			args: ["dropdownTrigger"]
		}]
	}
});
var ListComponent = class ListComponent {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: ListComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.1.6",
		type: ListComponent,
		isStandalone: true,
		selector: "cica-ui-list",
		ngImport: i0,
		template: `
    <div class="ui-list">
      <ng-content></ng-content>
    </div>
  `,
		isInline: true,
		styles: [":host{display:block;width:100%}:host .ui-list{display:flex;flex-direction:column;width:100%}\n"]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.1.6",
	ngImport: i0,
	type: ListComponent,
	decorators: [{
		type: Component,
		args: [{
			imports: [],
			selector: "cica-ui-list",
			template: `
    <div class="ui-list">
      <ng-content></ng-content>
    </div>
  `,
			styles: [":host{display:block;width:100%}:host .ui-list{display:flex;flex-direction:column;width:100%}\n"]
		}]
	}]
});
var ListItemComponent = class ListItemComponent {
	button = input(false, ...ngDevMode ? [{ debugName: "button" }] : 	/* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: ListItemComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.1.6",
		type: ListItemComponent,
		isStandalone: true,
		selector: "cica-ui-list-item",
		inputs: { button: {
			classPropertyName: "button",
			publicName: "button",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		ngImport: i0,
		template: `
    <div
      class="ui-list-item"
      [class.clickable]="button()"
    >
      <div class="item-start">
        <ng-content select="[slot=start]"></ng-content>
      </div>

      <div class="item-content">
        <ng-content></ng-content>
      </div>

      <div class="item-end">
        <ng-content select="[slot=end]"></ng-content>
      </div>
    </div>
  `,
		isInline: true,
		styles: [":host{display:block;width:100%}.ui-list-item{display:flex;align-items:center;min-height:48px;padding:8px 16px;gap:12px;box-sizing:border-box;border-bottom:1px solid var(--ui-border-color, #e5e5e5)}:host(:last-child) .ui-list-item{border-bottom:none}.item-start,.item-end{display:flex;align-items:center;flex-shrink:0}.item-content{flex:1;min-width:0}.clickable{cursor:pointer}.clickable:hover{background:var(--ui-hover-background, #f5f5f5)}\n"]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.1.6",
	ngImport: i0,
	type: ListItemComponent,
	decorators: [{
		type: Component,
		args: [{
			imports: [],
			selector: "cica-ui-list-item",
			template: `
    <div
      class="ui-list-item"
      [class.clickable]="button()"
    >
      <div class="item-start">
        <ng-content select="[slot=start]"></ng-content>
      </div>

      <div class="item-content">
        <ng-content></ng-content>
      </div>

      <div class="item-end">
        <ng-content select="[slot=end]"></ng-content>
      </div>
    </div>
  `,
			styles: [":host{display:block;width:100%}.ui-list-item{display:flex;align-items:center;min-height:48px;padding:8px 16px;gap:12px;box-sizing:border-box;border-bottom:1px solid var(--ui-border-color, #e5e5e5)}:host(:last-child) .ui-list-item{border-bottom:none}.item-start,.item-end{display:flex;align-items:center;flex-shrink:0}.item-content{flex:1;min-width:0}.clickable{cursor:pointer}.clickable:hover{background:var(--ui-hover-background, #f5f5f5)}\n"]
		}]
	}],
	propDecorators: { button: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "button",
			required: false
		}]
	}] }
});
var CollectionsComponent = class CollectionsComponent {
	items = input.required(...ngDevMode ? [{ debugName: "items" }] : 	/* istanbul ignore next */ []);
	columns = input(3, ...ngDevMode ? [{ debugName: "columns" }] : 	/* istanbul ignore next */ []);
	notFoundText = input(...ngDevMode ? [void 0, { debugName: "notFoundText" }] : 	/* istanbul ignore next */ []);
	tempate = contentChild("itemTemplate", ...ngDevMode ? [{ debugName: "tempate" }] : 	/* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: CollectionsComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.1.6",
		type: CollectionsComponent,
		isStandalone: true,
		selector: "cica-collections",
		inputs: {
			items: {
				classPropertyName: "items",
				publicName: "items",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			columns: {
				classPropertyName: "columns",
				publicName: "columns",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			notFoundText: {
				classPropertyName: "notFoundText",
				publicName: "notFoundText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		queries: [{
			propertyName: "tempate",
			first: true,
			predicate: ["itemTemplate"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "@for (item of items(); track $index) {\n  <div class=\"col-{{ columns() }}\">\n    <ng-container\n      [ngTemplateOutlet]=\"tempate()\"\n      [ngTemplateOutletContext]=\"{ item: item, index: $index }\"\n    >\n    </ng-container>\n  </div>\n} @empty {\n  @if (notFoundText()) {\n    <div class=\"empty-content\">\n      {{ notFoundText() }}\n    </div>\n  }\n}\n",
		styles: [":host{display:flex;flex-direction:row;flex-wrap:wrap;gap:16px}:host .col-1{width:calc((100% + -0px)*1)}:host .col-2{width:calc((100% - 16px)/2)}:host .col-3{width:calc((100% - 2 * 16px) / 3)}:host .col-4{width:calc((100% - 48px)/4)}:host .col-5{width:calc((100% - 64px)/5)}:host .col-6{width:calc((100% - 5 * 16px) / 6)}:host .col-7{width:calc((100% - 6 * 16px) / 7)}:host .col-8{width:calc((100% - 112px)/8)}:host .col-9{width:calc((100% - 8 * 16px) / 9)}:host .col-10{width:calc((100% - 144px)*.1)}:host .col-11{width:calc((100% - 10 * 16px) / 11)}:host .col-12{width:calc((100% - 11 * 16px) / 12)}\n"],
		dependencies: [{
			kind: "directive",
			type: NgTemplateOutlet,
			selector: "[ngTemplateOutlet]",
			inputs: [
				"ngTemplateOutletContext",
				"ngTemplateOutlet",
				"ngTemplateOutletInjector"
			]
		}]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.1.6",
	ngImport: i0,
	type: CollectionsComponent,
	decorators: [{
		type: Component,
		args: [{
			imports: [NgTemplateOutlet],
			selector: "cica-collections",
			template: "@for (item of items(); track $index) {\n  <div class=\"col-{{ columns() }}\">\n    <ng-container\n      [ngTemplateOutlet]=\"tempate()\"\n      [ngTemplateOutletContext]=\"{ item: item, index: $index }\"\n    >\n    </ng-container>\n  </div>\n} @empty {\n  @if (notFoundText()) {\n    <div class=\"empty-content\">\n      {{ notFoundText() }}\n    </div>\n  }\n}\n",
			styles: [":host{display:flex;flex-direction:row;flex-wrap:wrap;gap:16px}:host .col-1{width:calc((100% + -0px)*1)}:host .col-2{width:calc((100% - 16px)/2)}:host .col-3{width:calc((100% - 2 * 16px) / 3)}:host .col-4{width:calc((100% - 48px)/4)}:host .col-5{width:calc((100% - 64px)/5)}:host .col-6{width:calc((100% - 5 * 16px) / 6)}:host .col-7{width:calc((100% - 6 * 16px) / 7)}:host .col-8{width:calc((100% - 112px)/8)}:host .col-9{width:calc((100% - 8 * 16px) / 9)}:host .col-10{width:calc((100% - 144px)*.1)}:host .col-11{width:calc((100% - 10 * 16px) / 11)}:host .col-12{width:calc((100% - 11 * 16px) / 12)}\n"]
		}]
	}],
	propDecorators: {
		items: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "items",
				required: true
			}]
		}],
		columns: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "columns",
				required: false
			}]
		}],
		notFoundText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "notFoundText",
				required: false
			}]
		}],
		tempate: [{
			type: i0.ContentChild,
			args: ["itemTemplate", { isSignal: true }]
		}]
	}
});
var ModalService = class ModalService {
	appRef = inject(ApplicationRef);
	environmentInjector = inject(EnvironmentInjector);
	injector = inject(Injector);
	async openEditModal(config) {
		const injector = config.injector ?? this.injector;
		const loadSubmitForm = injector.get(SUBMIT_FORM_TOKEN_LOAD, null);
		if (typeof loadSubmitForm !== "function") throw new Error("No SubmitForm loader is configured in the provided injector.");
		const submitFormRef = createComponent(await loadSubmitForm(), {
			environmentInjector: config.environmentInjector ?? this.environmentInjector,
			elementInjector: injector,
			bindings: [inputBinding("initValue", () => config.modalOptions.initValue)]
		});
		this.appRef.attachView(submitFormRef.hostView);
		const componentRef = createComponent(ModalComponent, {
			environmentInjector: config.environmentInjector ?? this.environmentInjector,
			elementInjector: config.injector ?? this.injector,
			bindings: [
				inputBinding("cancelLabel", () => config.modalOptions?.cancelLabel),
				inputBinding("confirmLabel", () => config.modalOptions?.confirmLabel),
				inputBinding("headerText", () => config.modalOptions?.headerText),
				inputBinding("fullHeight", () => true),
				inputBinding("modalPosition", () => "right"),
				inputBinding("showWarningIcon", () => false)
			],
			projectableNodes: [[submitFormRef.location.nativeElement]]
		});
		componentRef.onDestroy(() => {
			if (!submitFormRef.hostView.destroyed) {
				this.appRef.detachView(submitFormRef.hostView);
				submitFormRef.destroy();
			}
		});
		this.attachView(componentRef, void 0);
		return {
			componentRef,
			submitFormRef
		};
	}
	openDeleteModal(config) {
		const content = config.modalOptions.content ?? "";
		let contentView;
		let contentNodes;
		if (typeof content === "string") {
			const span = document.createElement("span");
			span.textContent = content;
			contentNodes = [span];
		} else {
			contentView = content.createEmbeddedView({});
			contentView.detectChanges();
			contentNodes = contentView.rootNodes;
		}
		const componentRef = createComponent(ModalComponent, {
			environmentInjector: config.environmentInjector ?? this.environmentInjector,
			elementInjector: config.injector ?? this.injector,
			bindings: [
				inputBinding("cancelLabel", () => config.modalOptions?.cancelLabel),
				inputBinding("confirmLabel", () => config.modalOptions?.confirmLabel),
				inputBinding("headerText", () => config.modalOptions?.headerText),
				inputBinding("fullHeight", () => config.modalOptions?.fullHeight),
				inputBinding("modalPosition", () => "center"),
				inputBinding("showWarningIcon", () => true)
			],
			projectableNodes: [contentNodes]
		});
		this.attachView(componentRef, contentView);
		return componentRef;
	}
	close(componentRef) {
		destroy(this.appRef, componentRef);
	}
	attachView(componentRef, contentView) {
		componentRef.onDestroy(() => contentView?.destroy());
		this.appRef.attachView(componentRef.hostView);
		document.body.appendChild(componentRef.location.nativeElement);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: ModalService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Service
	});
	static ɵprov = i0.ɵɵngDeclareService({
		minVersion: "22.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: ModalService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.1.6",
	ngImport: i0,
	type: ModalService,
	decorators: [{ type: Service }]
});
function destroy(appRef, componentRef) {
	appRef.detachView(componentRef.hostView);
	componentRef.destroy();
}
function templateToNodes(template, viewContainer) {
	if (typeof template === "string") {
		const span = document.createElement("span");
		span.textContent = template;
		return [span];
	}
	const view = viewContainer.createEmbeddedView(template);
	view.detectChanges();
	return [...view.rootNodes];
}
function closeModal(appRef, ref, submitFormComponentRef) {
	const componentRef = ref;
	ref = void 0;
	submitFormComponentRef?.destroy();
	submitFormComponentRef = void 0;
	if (!componentRef) return;
	componentRef.location.nativeElement.remove();
	if (componentRef.hostView.destroyed) return;
	destroy(appRef, componentRef);
}
function createSubmitForm(component, viewContainer, injector, environmentInjector, initValue) {
	return viewContainer.createComponent(component, {
		injector,
		environmentInjector,
		bindings: [inputBinding("initValue", () => initValue ? structuredClone(initValue) : initValue)]
	});
}
const SUBMIT_FORM_TOKEN_LOAD = new InjectionToken("submit.form.token.load");
const SUBMIT_FORM_TOKEN = new InjectionToken("app.config");
var ModalDirective = class ModalDirective {
	appRef = inject(ApplicationRef);
	environmentInjector = inject(EnvironmentInjector);
	injector = inject(Injector);
	modalService = inject(ModalService);
	initValue = input(...ngDevMode ? [void 0, { debugName: "initValue" }] : 	/* istanbul ignore next */ []);
	cicaModal = input.required(...ngDevMode ? [{ debugName: "cicaModal" }] : 	/* istanbul ignore next */ []);
	cancelLabel = input(...ngDevMode ? [void 0, { debugName: "cancelLabel" }] : 	/* istanbul ignore next */ []);
	confirmLabel = input(...ngDevMode ? [void 0, { debugName: "confirmLabel" }] : 	/* istanbul ignore next */ []);
	showWarningIcon = input(false, ...ngDevMode ? [{ debugName: "showWarningIcon" }] : 	/* istanbul ignore next */ []);
	fullHeight = input(false, ...ngDevMode ? [{ debugName: "fullHeight" }] : 	/* istanbul ignore next */ []);
	modalPosition = input("center", ...ngDevMode ? [{ debugName: "modalPosition" }] : 	/* istanbul ignore next */ []);
	isDelete = input(false, ...ngDevMode ? [{ debugName: "isDelete" }] : 	/* istanbul ignore next */ []);
	headerText = input(...ngDevMode ? [void 0, { debugName: "headerText" }] : 	/* istanbul ignore next */ []);
	onConfirm = output();
	onSuccess = output();
	modalOpenEvent = output();
	onCancel = output();
	componentRef;
	submitFormComponentRef;
	async handleClick() {
		if (!this.isDelete() && await this.injector.get(SUBMIT_FORM_TOKEN_LOAD, null)?.()) {
			const { componentRef, submitFormRef } = await this.modalService.openEditModal({
				environmentInjector: this.environmentInjector,
				injector: this.injector,
				modalOptions: {
					modalPosition: "right",
					confirmLabel: this.confirmLabel(),
					headerText: this.headerText(),
					initValue: this.initValue()
				}
			});
			componentRef.instance.onCancel.subscribe(() => {
				this.modalService.close(componentRef);
			});
			componentRef.instance.onConfirm.subscribe(() => {
				submit(submitFormRef.instance.form);
			});
			submitFormRef.instance.onClose.subscribe(() => {
				this.modalService.close(componentRef);
			});
		} else {
			const modalRef = this.modalService.openDeleteModal({ modalOptions: {
				modalPosition: "center",
				confirmLabel: this.confirmLabel(),
				headerText: this.headerText(),
				content: this.cicaModal()
			} });
			modalRef.instance.onCancel.subscribe(() => {
				closeModal(this.appRef, modalRef, this.submitFormComponentRef);
			});
			modalRef.instance.onConfirm.subscribe(() => {
				closeModal(this.appRef, modalRef, this.submitFormComponentRef);
				this.onConfirm.emit({
					componentRef: modalRef,
					appRef: this.appRef
				});
			});
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: ModalDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.1.6",
		type: ModalDirective,
		isStandalone: true,
		selector: "[cicaModal]",
		inputs: {
			initValue: {
				classPropertyName: "initValue",
				publicName: "initValue",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			cicaModal: {
				classPropertyName: "cicaModal",
				publicName: "cicaModal",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			cancelLabel: {
				classPropertyName: "cancelLabel",
				publicName: "cancelLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			confirmLabel: {
				classPropertyName: "confirmLabel",
				publicName: "confirmLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showWarningIcon: {
				classPropertyName: "showWarningIcon",
				publicName: "showWarningIcon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fullHeight: {
				classPropertyName: "fullHeight",
				publicName: "fullHeight",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			modalPosition: {
				classPropertyName: "modalPosition",
				publicName: "modalPosition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isDelete: {
				classPropertyName: "isDelete",
				publicName: "isDelete",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			headerText: {
				classPropertyName: "headerText",
				publicName: "headerText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			onConfirm: "onConfirm",
			onSuccess: "onSuccess",
			modalOpenEvent: "modalOpenEvent",
			onCancel: "onCancel"
		},
		host: { listeners: { "click": "handleClick()" } },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.1.6",
	ngImport: i0,
	type: ModalDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[cicaModal]",
			host: { "(click)": "handleClick()" }
		}]
	}],
	propDecorators: {
		initValue: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "initValue",
				required: false
			}]
		}],
		cicaModal: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "cicaModal",
				required: true
			}]
		}],
		cancelLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "cancelLabel",
				required: false
			}]
		}],
		confirmLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "confirmLabel",
				required: false
			}]
		}],
		showWarningIcon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showWarningIcon",
				required: false
			}]
		}],
		fullHeight: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fullHeight",
				required: false
			}]
		}],
		modalPosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "modalPosition",
				required: false
			}]
		}],
		isDelete: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isDelete",
				required: false
			}]
		}],
		headerText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "headerText",
				required: false
			}]
		}],
		onConfirm: [{
			type: i0.Output,
			args: ["onConfirm"]
		}],
		onSuccess: [{
			type: i0.Output,
			args: ["onSuccess"]
		}],
		modalOpenEvent: [{
			type: i0.Output,
			args: ["modalOpenEvent"]
		}],
		onCancel: [{
			type: i0.Output,
			args: ["onCancel"]
		}]
	}
});
var TooltipDirective = class TooltipDirective {
	cicaTooltip = input.required(...ngDevMode ? [{ debugName: "cicaTooltip" }] : 	/* istanbul ignore next */ []);
	customTrigger = input(false, ...ngDevMode ? [{ debugName: "customTrigger" }] : 	/* istanbul ignore next */ []);
	tooltipPosition = input("top", ...ngDevMode ? [{ debugName: "tooltipPosition" }] : 	/* istanbul ignore next */ []);
	tooltipElement = null;
	tooltipView;
	showTimeout;
	hideTimeout;
	elementRef = inject(ElementRef);
	renderer = inject(Renderer2);
	viewContainerRef = inject(ViewContainerRef);
	onMouseEnter() {
		if (!this.customTrigger()) {
			this.clearTimeouts();
			this.showTimeout = setTimeout(() => {
				this.show();
			}, 100);
		}
	}
	onMouseLeave() {
		if (!this.customTrigger()) {
			this.clearTimeouts();
			this.hideTimeout = setTimeout(() => {
				this.hide();
			}, 100);
		}
	}
	show() {
		if (!this.cicaTooltip() || this.tooltipElement) return;
		const host = this.elementRef.nativeElement;
		const tooltip = this.renderer.createElement("div");
		if (typeof this.cicaTooltip() === "string") this.renderer.setProperty(tooltip, "textContent", this.cicaTooltip());
		else {
			this.renderer.addClass(tooltip, "app-tooltip-interactive");
			this.tooltipView = this.viewContainerRef.createEmbeddedView(this.cicaTooltip());
			this.tooltipView.detectChanges();
			for (const rootNode of this.tooltipView.rootNodes) this.renderer.appendChild(tooltip, rootNode);
		}
		const preferredPosition = this.tooltipPosition();
		this.renderer.addClass(tooltip, "app-tooltip");
		this.renderer.addClass(tooltip, `app-tooltip-${preferredPosition}`);
		this.renderer.appendChild(document.body, tooltip);
		this.tooltipElement = tooltip;
		this.positionTooltip(host, tooltip, preferredPosition);
		requestAnimationFrame(() => {
			this.renderer.addClass(tooltip, "app-tooltip-visible");
		});
	}
	hide() {
		if (!this.tooltipElement) return;
		const tooltip = this.tooltipElement;
		const tooltipView = this.tooltipView;
		this.tooltipView = void 0;
		this.renderer.removeClass(tooltip, "app-tooltip-visible");
		setTimeout(() => {
			this.renderer.removeChild(document.body, tooltip);
			tooltipView?.destroy();
		}, 100);
		this.tooltipElement = null;
	}
	positionTooltip(host, tooltip, preferredPosition) {
		const hostRect = host.getBoundingClientRect();
		const tooltipRect = tooltip.getBoundingClientRect();
		const gap = 8;
		const edge = 8;
		const viewportWidth = document.documentElement.clientWidth;
		const viewportHeight = document.documentElement.clientHeight;
		const fits = {
			top: hostRect.top >= tooltipRect.height + gap + edge,
			bottom: viewportHeight - hostRect.bottom >= tooltipRect.height + gap + edge,
			left: hostRect.left >= tooltipRect.width + gap + edge,
			right: viewportWidth - hostRect.right >= tooltipRect.width + gap + edge
		};
		const opposite = {
			top: "bottom",
			bottom: "top",
			left: "right",
			right: "left"
		};
		const position = fits[preferredPosition] ? preferredPosition : fits[opposite[preferredPosition]] ? opposite[preferredPosition] : Object.keys(fits).find((side) => fits[side]) ?? preferredPosition;
		this.renderer.removeClass(tooltip, `app-tooltip-${preferredPosition}`);
		this.renderer.addClass(tooltip, `app-tooltip-${position}`);
		let top;
		let left;
		console.log(tooltipRect);
		switch (position) {
			case "bottom":
				top = hostRect.bottom + gap;
				left = hostRect.left + (hostRect.width - tooltipRect.width) / 2;
				break;
			case "left":
				top = hostRect.top + (hostRect.height - tooltipRect.height) / 2;
				left = hostRect.left - tooltipRect.width - gap;
				break;
			case "right":
				top = hostRect.top + (hostRect.height - tooltipRect.height) / 2;
				left = hostRect.right + gap;
				break;
			default:
				top = hostRect.top - tooltipRect.height - gap;
				left = hostRect.left + (hostRect.width - tooltipRect.width) / 2;
		}
		top = Math.max(edge, Math.min(top, viewportHeight - tooltipRect.height - edge));
		left = Math.max(edge, Math.min(left, viewportWidth - tooltipRect.width - edge));
		this.renderer.setStyle(tooltip, "top", `${top}px`);
		this.renderer.setStyle(tooltip, "left", `${left}px`);
	}
	clearTimeouts() {
		if (this.showTimeout) clearTimeout(this.showTimeout);
		if (this.hideTimeout) clearTimeout(this.hideTimeout);
	}
	ngOnDestroy() {
		this.clearTimeouts();
		this.hide();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: TooltipDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.1.6",
		type: TooltipDirective,
		isStandalone: true,
		selector: "[cicaTooltip]",
		inputs: {
			cicaTooltip: {
				classPropertyName: "cicaTooltip",
				publicName: "cicaTooltip",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			customTrigger: {
				classPropertyName: "customTrigger",
				publicName: "customTrigger",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tooltipPosition: {
				classPropertyName: "tooltipPosition",
				publicName: "tooltipPosition",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { listeners: {
			"mouseleave": "onMouseLeave()",
			"mouseenter": "onMouseEnter()"
		} },
		exportAs: ["cicaTooltip"],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.1.6",
	ngImport: i0,
	type: TooltipDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[cicaTooltip]",
			exportAs: "cicaTooltip",
			host: {
				"(mouseleave)": "onMouseLeave()",
				"(mouseenter)": "onMouseEnter()"
			}
		}]
	}],
	propDecorators: {
		cicaTooltip: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "cicaTooltip",
				required: true
			}]
		}],
		customTrigger: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "customTrigger",
				required: false
			}]
		}],
		tooltipPosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tooltipPosition",
				required: false
			}]
		}]
	}
});
var DebounceInputDirective = class DebounceInputDirective {
	debounceTime = input(300, ...ngDevMode ? [{ debugName: "debounceTime" }] : 	/* istanbul ignore next */ []);
	cicaDebounceInput = output();
	el = inject(ElementRef, { optional: true });
	input = inject(InputComponent, { optional: true });
	debouncedValue = toSignal((this.input ? toObservable(this.input.value).pipe(map((value) => String(value ?? ""))) : fromEvent(this.el.nativeElement, "input").pipe(map((event) => event.target.value))).pipe(debounceTime(this.debounceTime()), distinctUntilChanged()), { initialValue: this.input?.value() ?? this.el?.nativeElement.value ?? "" });
	constructor() {
		effect(() => {
			this.cicaDebounceInput.emit(this.debouncedValue() ?? "");
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: DebounceInputDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.1.6",
		type: DebounceInputDirective,
		isStandalone: true,
		selector: "[cicaDebounceInput]",
		inputs: { debounceTime: {
			classPropertyName: "debounceTime",
			publicName: "debounceTime",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		outputs: { cicaDebounceInput: "cicaDebounceInput" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.1.6",
	ngImport: i0,
	type: DebounceInputDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[cicaDebounceInput]" }]
	}],
	ctorParameters: () => [],
	propDecorators: {
		debounceTime: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "debounceTime",
				required: false
			}]
		}],
		cicaDebounceInput: [{
			type: i0.Output,
			args: ["cicaDebounceInput"]
		}]
	}
});
var BecomeVisibleDirective = class BecomeVisibleDirective {
	hostElement = inject(ElementRef);
	patentElement = input(...ngDevMode ? [void 0, { debugName: "patentElement" }] : 	/* istanbul ignore next */ []);
	rootMargin = input("20px", ...ngDevMode ? [{ debugName: "rootMargin" }] : 	/* istanbul ignore next */ []);
	threshold = input(.1, ...ngDevMode ? [{ debugName: "threshold" }] : 	/* istanbul ignore next */ []);
	cicaBecomeVisible = output();
	observer;
	constructor() {
		effect(() => {
			const root = this.patentElement();
			const rootMargin = this.rootMargin();
			const threshold = this.threshold();
			this.observer?.disconnect();
			this.observer = new IntersectionObserver((entries) => {
				if (entries.some((entry) => entry.isIntersecting)) this.cicaBecomeVisible.emit();
			}, {
				root,
				rootMargin,
				threshold
			});
			this.observer.observe(this.hostElement.nativeElement);
		});
	}
	ngOnDestroy() {
		this.observer?.disconnect();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: BecomeVisibleDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.1.6",
		type: BecomeVisibleDirective,
		isStandalone: true,
		selector: "[cicaBecomeVisible]",
		inputs: {
			patentElement: {
				classPropertyName: "patentElement",
				publicName: "patentElement",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rootMargin: {
				classPropertyName: "rootMargin",
				publicName: "rootMargin",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			threshold: {
				classPropertyName: "threshold",
				publicName: "threshold",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { cicaBecomeVisible: "cicaBecomeVisible" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.1.6",
	ngImport: i0,
	type: BecomeVisibleDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[cicaBecomeVisible]" }]
	}],
	ctorParameters: () => [],
	propDecorators: {
		patentElement: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "patentElement",
				required: false
			}]
		}],
		rootMargin: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rootMargin",
				required: false
			}]
		}],
		threshold: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "threshold",
				required: false
			}]
		}],
		cicaBecomeVisible: [{
			type: i0.Output,
			args: ["cicaBecomeVisible"]
		}]
	}
});
const FETCH_DATA = new InjectionToken("USER_ID");
var FetchDataDirective = class FetchDataDirective {
	fetchData = inject(FETCH_DATA);
	loading = false;
	hasMore = true;
	slot = 0;
	fetchDisabed = input(false, ...ngDevMode ? [{ debugName: "fetchDisabed" }] : 	/* istanbul ignore next */ []);
	filterParams = input({}, ...ngDevMode ? [{ debugName: "filterParams" }] : 	/* istanbul ignore next */ []);
	accumulatorCallBack = input((acc, curr) => [...acc, ...curr], ...ngDevMode ? [{ debugName: "accumulatorCallBack" }] : 	/* istanbul ignore next */ []);
	hasMoreCallBack = input((value) => !!value.length, ...ngDevMode ? [{ debugName: "hasMoreCallBack" }] : 	/* istanbul ignore next */ []);
	cicaFetchData = output();
	loadingChange = output();
	becomeVisibleHtml = input.required(...ngDevMode ? [{ debugName: "becomeVisibleHtml" }] : 	/* istanbul ignore next */ []);
	filterParamsAsObservable$;
	constructor() {
		this.filterParamsAsObservable$ = toObservable(this.filterParams);
	}
	ngOnInit() {
		if (!this.fetchDisabed()) merge(outputToObservable(this.becomeVisibleHtml().cicaBecomeVisible).pipe(filter(() => !this.loading && this.hasMore), tap(() => {
			this.slot++;
			window.scrollBy({
				top: -200,
				behavior: "instant"
			});
		})), this.filterParamsAsObservable$.pipe(tap(() => {
			this.slot = 0;
		}))).pipe(filter(() => false), switchMap(() => {
			this.setLoading(true);
			return this.fetchData(this.filterParams(), this.slot).pipe(tap((result) => {
				this.hasMore = this.hasMoreCallBack()(result);
				this.setLoading();
			}), catchError(() => {
				this.setLoading();
				return of([]);
			}));
		})).pipe(scan((acc, curr) => {
			if (this.slot === 0) return curr;
			return this.accumulatorCallBack()(acc, curr);
		}, [])).subscribe((data) => {
			this.cicaFetchData.emit(data);
		});
	}
	setLoading(loading = false) {
		this.loadingChange.emit(loading);
		this.loading = loading;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: FetchDataDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.1.6",
		type: FetchDataDirective,
		isStandalone: true,
		selector: "[cicaFetchData]",
		inputs: {
			fetchDisabed: {
				classPropertyName: "fetchDisabed",
				publicName: "fetchDisabed",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			filterParams: {
				classPropertyName: "filterParams",
				publicName: "filterParams",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			accumulatorCallBack: {
				classPropertyName: "accumulatorCallBack",
				publicName: "accumulatorCallBack",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hasMoreCallBack: {
				classPropertyName: "hasMoreCallBack",
				publicName: "hasMoreCallBack",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			becomeVisibleHtml: {
				classPropertyName: "becomeVisibleHtml",
				publicName: "becomeVisibleHtml",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: {
			cicaFetchData: "cicaFetchData",
			loadingChange: "loadingChange"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.1.6",
	ngImport: i0,
	type: FetchDataDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[cicaFetchData]" }]
	}],
	ctorParameters: () => [],
	propDecorators: {
		fetchDisabed: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fetchDisabed",
				required: false
			}]
		}],
		filterParams: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filterParams",
				required: false
			}]
		}],
		accumulatorCallBack: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "accumulatorCallBack",
				required: false
			}]
		}],
		hasMoreCallBack: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hasMoreCallBack",
				required: false
			}]
		}],
		cicaFetchData: [{
			type: i0.Output,
			args: ["cicaFetchData"]
		}],
		loadingChange: [{
			type: i0.Output,
			args: ["loadingChange"]
		}],
		becomeVisibleHtml: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "becomeVisibleHtml",
				required: true
			}]
		}]
	}
});
var FirstFocusDirective = class FirstFocusDirective {
	hostElement = inject(ElementRef);
	cicaFirstFocus = input(false, ...ngDevMode ? [{ debugName: "cicaFirstFocus" }] : 	/* istanbul ignore next */ []);
	ngOnInit() {
		if (this.cicaFirstFocus()) this.hostElement.nativeElement.focus();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: FirstFocusDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.1.6",
		type: FirstFocusDirective,
		isStandalone: true,
		selector: "[cicaFirstFocus]",
		inputs: { cicaFirstFocus: {
			classPropertyName: "cicaFirstFocus",
			publicName: "cicaFirstFocus",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.1.6",
	ngImport: i0,
	type: FirstFocusDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[cicaFirstFocus]" }]
	}],
	propDecorators: { cicaFirstFocus: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "cicaFirstFocus",
			required: false
		}]
	}] }
});
var VisiblilityChangeDirective = class VisiblilityChangeDirective {
	hostElement = inject(ElementRef);
	patentElement = input(...ngDevMode ? [void 0, { debugName: "patentElement" }] : 	/* istanbul ignore next */ []);
	rootMargin = input("20px", ...ngDevMode ? [{ debugName: "rootMargin" }] : 	/* istanbul ignore next */ []);
	threshold = input(.1, ...ngDevMode ? [{ debugName: "threshold" }] : 	/* istanbul ignore next */ []);
	cicaVisiblilityChange = output();
	observer;
	constructor() {
		combineLatest([
			toObservable(this.rootMargin),
			toObservable(this.threshold),
			toObservable(this.patentElement)
		]).pipe(takeUntilDestroyed()).subscribe(([rootMargin, threshold, root]) => {
			this.observer = subscribeOnElementAppear({
				rootMargin,
				threshold,
				root,
				callBackFunction: (isIntersecting) => {
					this.cicaVisiblilityChange.emit(isIntersecting);
				},
				observerElement: this.hostElement.nativeElement
			});
		});
	}
	ngOnDestroy() {
		this.observer?.unobserve(this.hostElement.nativeElement);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: VisiblilityChangeDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.1.6",
		type: VisiblilityChangeDirective,
		isStandalone: true,
		selector: "[cicaVisiblilityChange]",
		inputs: {
			patentElement: {
				classPropertyName: "patentElement",
				publicName: "patentElement",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rootMargin: {
				classPropertyName: "rootMargin",
				publicName: "rootMargin",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			threshold: {
				classPropertyName: "threshold",
				publicName: "threshold",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { cicaVisiblilityChange: "cicaVisiblilityChange" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.1.6",
	ngImport: i0,
	type: VisiblilityChangeDirective,
	decorators: [{
		type: Directive,
		args: [{ selector: "[cicaVisiblilityChange]" }]
	}],
	ctorParameters: () => [],
	propDecorators: {
		patentElement: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "patentElement",
				required: false
			}]
		}],
		rootMargin: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rootMargin",
				required: false
			}]
		}],
		threshold: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "threshold",
				required: false
			}]
		}],
		cicaVisiblilityChange: [{
			type: i0.Output,
			args: ["cicaVisiblilityChange"]
		}]
	}
});
function subscribeOnElementAppear(config) {
	const observer = new IntersectionObserver((entries) => {
		if (entries[0]) config.callBackFunction(entries[0].isIntersecting);
	}, {
		root: config.root,
		rootMargin: config.rootMargin ?? "200px",
		threshold: config.threshold ?? .1
	});
	observer.observe(config.observerElement);
	return observer;
}
var ToastService = class ToastService {
	maxStack = 3;
	position = "tr";
	container = null;
	icons = {
		success: "<svg viewBox=\"0 0 24 24\" width=\"20\" height=\"20\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><circle cx=\"12\" cy=\"12\" r=\"10\"/><path d=\"m8 12 3 3 5-6\"/></svg>",
		error: "<svg viewBox=\"0 0 24 24\" width=\"20\" height=\"20\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><circle cx=\"12\" cy=\"12\" r=\"10\"/><path d=\"m15 9-6 6M9 9l6 6\"/></svg>",
		warning: "<svg viewBox=\"0 0 24 24\" width=\"20\" height=\"20\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z\"/><path d=\"M12 9v4M12 17h.01\"/></svg>",
		info: "<svg viewBox=\"0 0 24 24\" width=\"20\" height=\"20\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><circle cx=\"12\" cy=\"12\" r=\"10\"/><path d=\"M12 16v-4M12 8h.01\"/></svg>"
	};
	constructor() {
		this.container = document.querySelector(`.toast-container[data-position="${this.position}"]`);
		if (!this.container) {
			this.container = document.createElement("div");
			this.container.className = "toast-container";
			this.container.dataset["position"] = this.position;
			this.container.setAttribute("role", "region");
			this.container.setAttribute("aria-label", "Notifications");
			document.body.append(this.container);
		}
	}
	success(message, title = "", duration = 4e3) {
		this.show("success", message, title, duration);
	}
	error(message, title = "", duration = 4e3) {
		this.show("error", message, title, duration);
	}
	warning(message, title = "", duration = 4e3) {
		this.show("warning", message, title, duration);
	}
	info(message, title = "", duration = 4e3) {
		this.show("info", message, title, duration);
	}
	show(type, message, title = "", duration = 4e3) {
		const open = this.container.querySelectorAll(".toast:not(.is-leaving)");
		if (open.length >= this.maxStack) this.dismiss(duration, open[0]);
		const t = document.createElement("div");
		t.className = `toast toast-${type}`;
		t.setAttribute("role", type === "error" ? "alert" : "status");
		t.innerHTML = `<span class="toast-icon" aria-hidden="true">${this.icons[type]}</span>
      <div class="toast-body"><strong class="toast-title"></strong><p class="toast-message"></p></div>
      <button type="button" class="toast-close" aria-label="Dismiss notification">&times;</button>
      <span class="toast-progress"></span>`;
		t.querySelector(".toast-title").textContent = title;
		t.querySelector(".toast-message").textContent = message;
		t.querySelector(".toast-close").addEventListener("click", () => this.dismiss(duration, t));
		if (duration > 0) {
			t.style.setProperty("--toast-duration", duration + "ms");
			t.querySelector(".toast-progress").addEventListener("animationend", () => this.dismiss(duration, t));
		} else t.classList.add("is-sticky");
		this.container.append(t);
		return t;
	}
	dismiss(duration, t) {
		if (!t || t.classList.contains("is-leaving")) return;
		t.classList.add("is-leaving");
		const remove = () => t.remove();
		t.addEventListener("animationend", (e) => {
			if (e.target === t) remove();
		});
		setTimeout(remove, duration);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: ToastService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Service
	});
	static ɵprov = i0.ɵɵngDeclareService({
		minVersion: "22.0.0",
		version: "22.1.6",
		ngImport: i0,
		type: ToastService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.1.6",
	ngImport: i0,
	type: ToastService,
	decorators: [{ type: Service }],
	ctorParameters: () => []
});
export { BecomeVisibleDirective, CardComponent, CollectionsComponent, DebounceInputDirective, FETCH_DATA, FetchDataDirective, FirstFocusDirective, InputComponent, ListComponent, ListItemComponent, MenuButtonComponent, ModalComponent, ModalDirective, ModalService, SUBMIT_FORM_TOKEN, SUBMIT_FORM_TOKEN_LOAD, SidebarLinkComponent, SidebarLinkTemplateDirective, SidebarWrapperComponent, ToastService, TooltipDirective, VisiblilityChangeDirective, closeModal, createSubmitForm, destroy, subscribeOnElementAppear, templateToNodes };

//# sourceMappingURL=cica-ui.mjs.map