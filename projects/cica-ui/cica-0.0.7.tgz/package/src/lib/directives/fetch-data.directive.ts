import { Directive, inject, InjectionToken, input, OnInit, output } from '@angular/core';
import { catchError, filter, merge, Observable, of, scan, switchMap, tap } from 'rxjs';
import { toObservable } from '@angular/core/rxjs-interop';
import { outputToObservable } from '@angular/core/rxjs-interop';
import { BecomeVisibleDirective } from './become-visible-directive';

export const FETCH_DATA = new InjectionToken<(filter: any, slot?: number) => Observable<any[]>>(
  'USER_ID',
);

@Directive({
  selector: '[cicaFetchData]',
})
export class FetchDataDirective<T> implements OnInit {
  private readonly fetchData = inject(FETCH_DATA);
  private loading = false;
  private hasMore = true;
  private slot = 0;
  fetchDisabed = input(false);
  filterParams = input<any>({});
  accumulatorCallBack = input<(acc: any[], curr: any[]) => any[]>((acc: any[], curr: any[]) => [
    ...acc,
    ...curr,
  ]);
  hasMoreCallBack = input<(value: any[]) => boolean>((value: any[]) => !!value.length);
  cicaFetchData = output<T[]>();
  loadingChange = output<boolean>();
  becomeVisibleHtml = input.required<BecomeVisibleDirective>();
  filterParamsAsObservable$!: Observable<any>;

  constructor() {
    this.filterParamsAsObservable$ = toObservable(this.filterParams);
  }

  ngOnInit(): void {
    if (!this.fetchDisabed()) {
      merge(
        outputToObservable(this.becomeVisibleHtml().cicaBecomeVisible).pipe(
          filter(() => !this.loading && this.hasMore),
          tap(() => {
            this.slot++;
            window.scrollBy({
              top: -200,
              behavior: 'instant',
            });
          }),
        ),
        this.filterParamsAsObservable$.pipe(
          tap(() => {
            this.slot = 0;
          }),
        ),
      )
        .pipe(
          filter(() => false),
          switchMap(() => {
            this.setLoading(true);
            return this.fetchData(this.filterParams(), this.slot).pipe(
              tap((result) => {
                this.hasMore = this.hasMoreCallBack()(result);
                this.setLoading();
              }),
              catchError(() => {
                this.setLoading();
                return of([] as T[]);
              }),
            );
          }),
        )
        .pipe(
          scan((acc, curr) => {
            if (this.slot === 0) {
              return curr;
            }
            return this.accumulatorCallBack()(acc, curr);
          }, [] as T[]),
        )
        .subscribe((data) => {
          this.cicaFetchData.emit(data);
        });
    }
  }

  private setLoading(loading = false): void {
    this.loadingChange.emit(loading);
    this.loading = loading;
  }
}
